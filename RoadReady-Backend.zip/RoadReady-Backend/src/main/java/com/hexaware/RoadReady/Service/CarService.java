package com.hexaware.RoadReady.Service;

import com.hexaware.RoadReady.DTO.CarDTO;

import java.util.List;

public interface CarService {
    CarDTO addCar(CarDTO carDTO);
    CarDTO updateCar(Long id, CarDTO carDTO);
    void deleteCar(Long id);
    CarDTO getCarById(Long id);
    List<CarDTO> getAllCars();
}
