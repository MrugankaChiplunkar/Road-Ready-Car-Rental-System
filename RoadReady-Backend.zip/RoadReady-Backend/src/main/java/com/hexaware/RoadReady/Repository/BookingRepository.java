package com.hexaware.RoadReady.Repository;

import com.hexaware.RoadReady.Entity.Booking;
import com.hexaware.RoadReady.Entity.Car;
import com.hexaware.RoadReady.Entity.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByUser(User user);

    boolean existsByCarAndPickupDateLessThanEqualAndDropoffDateGreaterThanEqual(
        Car car, LocalDate dropoffDate, LocalDate pickupDate);
    
    List<Booking> findByUserId(Long userId);

}
