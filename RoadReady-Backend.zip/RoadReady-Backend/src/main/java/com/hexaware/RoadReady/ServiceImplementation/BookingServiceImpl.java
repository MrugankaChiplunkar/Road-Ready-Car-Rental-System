package com.hexaware.RoadReady.ServiceImplementation;

import com.hexaware.RoadReady.DTO.BookingDTO;
import com.hexaware.RoadReady.Entity.Booking;
import com.hexaware.RoadReady.Entity.Car;
import com.hexaware.RoadReady.Entity.User;
import com.hexaware.RoadReady.Repository.BookingRepository;
import com.hexaware.RoadReady.Repository.CarRepository;
import com.hexaware.RoadReady.Repository.UserRepository;
import com.hexaware.RoadReady.Service.BookingService;
import com.hexaware.RoadReady.Exception.BookingNotFoundException;


import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final CarRepository carRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    @Override
    public BookingDTO bookCar(BookingDTO bookingDTO) {
        Car car = carRepository.findById(bookingDTO.getCarId())
                .orElseThrow(() -> new RuntimeException("Car not found"));

     // Extract username from SecurityContext
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));


        // prevent double booking
        boolean conflict = bookingRepository
                .existsByCarAndPickupDateLessThanEqualAndDropoffDateGreaterThanEqual(
                        car, bookingDTO.getDropoffDate(), bookingDTO.getPickupDate());

        if (conflict) {
            throw new RuntimeException("Car is already booked for the selected dates");
        }

        long days = ChronoUnit.DAYS.between(bookingDTO.getPickupDate(), bookingDTO.getDropoffDate());
        double totalCost = days * car.getPricePerDay();

        Booking booking = Booking.builder()
                .car(car)
                .user(user)
                .pickupDate(bookingDTO.getPickupDate())
                .dropoffDate(bookingDTO.getDropoffDate())
                .totalCost(totalCost)
                .build();

        return modelMapper.map(bookingRepository.save(booking), BookingDTO.class);
    }

    @Override
    public List<BookingDTO> getBookingsByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return bookingRepository.findByUser(user).stream()
                .map(booking -> modelMapper.map(booking, BookingDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public void cancelBooking(Long bookingId) {
    	Booking booking = bookingRepository.findById(bookingId)
    	        .orElseThrow(() -> new BookingNotFoundException("Booking with ID " + bookingId + " not found"));

        String loggedInEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        User currentUser = userRepository.findByEmail(loggedInEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        boolean isAdmin = currentUser.getRole().name().equals("ADMIN");

        if (!isAdmin && !booking.getUser().getId().equals(currentUser.getId())) {
            throw new SecurityException("You are not authorized to cancel this booking");
        }

        bookingRepository.deleteById(bookingId);
    }

    
    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
    
    @Override
    public List<BookingDTO> getBookingsForLoggedInUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return bookingRepository.findByUser(user).stream()
                .map(booking -> modelMapper.map(booking, BookingDTO.class))
                .collect(Collectors.toList());
    }
    
    @Override
    public BookingDTO getBookingById(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        return modelMapper.map(booking, BookingDTO.class);
    }



}
