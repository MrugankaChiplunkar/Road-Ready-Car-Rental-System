package com.hexaware.RoadReady.DTO;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CarDTO {
    private Long id;
    private String make;
    private String model;
    private int year;
    private double pricePerDay;
    private boolean available;
    private String location;
    private String imageUrl;
}
