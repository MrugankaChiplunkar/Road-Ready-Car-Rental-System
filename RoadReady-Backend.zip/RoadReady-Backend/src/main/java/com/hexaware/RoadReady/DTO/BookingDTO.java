package com.hexaware.RoadReady.DTO;

import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingDTO {
    private Long id;
    private LocalDate pickupDate;
    private LocalDate dropoffDate;
    private double totalCost;
    private Long carId;
}

