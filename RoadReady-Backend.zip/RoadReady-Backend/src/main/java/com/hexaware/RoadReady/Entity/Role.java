//enum
package com.hexaware.RoadReady.Entity;

public enum Role {
    USER,
    ADMIN
}
