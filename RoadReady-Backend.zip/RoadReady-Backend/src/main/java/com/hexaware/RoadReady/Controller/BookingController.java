package com.hexaware.RoadReady.Controller;

import com.hexaware.RoadReady.DTO.BookingDTO;
import com.hexaware.RoadReady.Entity.Booking;
import com.hexaware.RoadReady.Service.BookingService;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.security.access.prepost.PreAuthorize;


import java.util.List;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    //  Book a car
    @PostMapping
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public BookingDTO bookCar(@RequestBody BookingDTO bookingDTO) {
        return bookingService.bookCar(bookingDTO);
    }


    // View bookings by user
    @GetMapping("/user")
    public List<BookingDTO> getMyBookings() {
        return bookingService.getBookingsForLoggedInUser();
    }


    // Cancel booking
    @DeleteMapping("/{bookingId}")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public String cancelBooking(@PathVariable Long bookingId) {
        bookingService.cancelBooking(bookingId);
        return "Booking with ID " + bookingId + " cancelled successfully.";
    }

    
 // ADMIN: View all bookings
    @GetMapping("/admin/all")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Booking> getAllBookings() {
        return bookingService.getAllBookings();
    }
    
 // Get booking by ID
    @GetMapping("/{bookingId}")
    @PreAuthorize("hasAnyRole('USER','ADMIN')")
    public BookingDTO getBookingById(@PathVariable Long bookingId) {
        return bookingService.getBookingById(bookingId);
    }

    

}
