package com.hexaware.RoadReady.DTO;

import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentDTO {

    private Long id;

    private String paymentMethod;

    private String status;

    private double amount;

    private LocalDateTime paymentDate;

    private Long bookingId;
}
