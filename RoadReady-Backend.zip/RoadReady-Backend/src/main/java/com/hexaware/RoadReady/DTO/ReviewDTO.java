package com.hexaware.RoadReady.DTO;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewDTO {
    private Long id;
    private int rating;
    private String comment;
    private LocalDateTime postedAt;
    private Long carId;
    private Long userId;
    private Long bookingId;
}