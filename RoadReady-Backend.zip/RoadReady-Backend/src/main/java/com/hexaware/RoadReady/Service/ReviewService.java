package com.hexaware.RoadReady.Service;

import com.hexaware.RoadReady.DTO.ReviewDTO;
import java.util.List;

public interface ReviewService {

    ReviewDTO postReview(Long bookingId, int rating, String comment, String userEmail);

    List<ReviewDTO> getReviewsForCar(Long carId);

    List<ReviewDTO> getAllReviews();

    void deleteReview(Long reviewId);
    
    List<ReviewDTO> getReviewsByUser(String email);

}