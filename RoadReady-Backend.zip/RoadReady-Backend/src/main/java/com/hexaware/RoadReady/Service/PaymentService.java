package com.hexaware.RoadReady.Service;

import java.util.List;

import com.hexaware.RoadReady.DTO.PaymentDTO;

public interface PaymentService {

    PaymentDTO processPayment(Long bookingId, String paymentMethod);
    
 // View payment by booking ID
    PaymentDTO getPaymentByBookingId(Long bookingId);

    // View all payments (for admin dashboard)
    List<PaymentDTO> getAllPayments();

    
    List<PaymentDTO> getPaymentsForLoggedInUser();


}
