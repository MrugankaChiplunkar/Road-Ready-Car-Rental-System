package com.hexaware.RoadReady.DTO;

import lombok.Data;

@Data
public class UserDTO {
    private String email;
    private String password;
}
