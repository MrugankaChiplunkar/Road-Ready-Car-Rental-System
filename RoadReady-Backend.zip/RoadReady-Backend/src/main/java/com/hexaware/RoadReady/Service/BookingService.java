package com.hexaware.RoadReady.Service;

import com.hexaware.RoadReady.DTO.BookingDTO;
import com.hexaware.RoadReady.Entity.Booking;

import java.util.List;

public interface BookingService {

    BookingDTO bookCar(BookingDTO bookingDTO);

    List<BookingDTO> getBookingsByUser(Long userId);

    void cancelBooking(Long bookingId);
    
    List<Booking> getAllBookings();

    List<BookingDTO> getBookingsForLoggedInUser();

    BookingDTO getBookingById(Long bookingId);


}
