package com.hexaware.RoadReady.Controller;

import com.hexaware.RoadReady.DTO.ReviewDTO;
import com.hexaware.RoadReady.Service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    // Post a review (Authenticated users only)
    @PostMapping("/post/{bookingId}")
    @PreAuthorize("hasRole('USER')")
    public ReviewDTO submitReview(@PathVariable Long bookingId,
                                  @RequestBody ReviewDTO reviewDTO,
                                  Authentication authentication) {
        String email = authentication.getName();
        return reviewService.postReview(
            bookingId,
            reviewDTO.getRating(),
            reviewDTO.getComment(),
            email
        );
    }

      

    //Get all reviews for a car 
    @GetMapping("/car/{carId}")
    public List<ReviewDTO> getReviews(@PathVariable Long carId) {
        return reviewService.getReviewsForCar(carId);
    }

    //Admin - Get all reviews
    @GetMapping("/admin/all")
    @PreAuthorize("hasRole('ADMIN')")
    public List<ReviewDTO> getAllReviews() {
        return reviewService.getAllReviews();
    }

    //Admin - Delete a review
    @DeleteMapping("/{reviewId}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteReview(@PathVariable Long reviewId) {
        reviewService.deleteReview(reviewId);
        return "Review with ID " + reviewId + " deleted successfully.";
    }
    
    
    @GetMapping("/me")
    @PreAuthorize("hasRole('USER')")
    public List<ReviewDTO> getMyReviews(Authentication auth) {
        String email = auth.getName();
        return reviewService.getReviewsByUser(email);
    }

}