package com.hexaware.RoadReady.Controller;

import com.hexaware.RoadReady.Config.JwtService;
import com.hexaware.RoadReady.DTO.UserDTO;
import com.hexaware.RoadReady.Entity.Role;
import com.hexaware.RoadReady.Entity.User;
import com.hexaware.RoadReady.Repository.UserRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import org.springframework.security.access.prepost.PreAuthorize;
import java.util.List;


import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class UserController {

    private final UserRepository userRepository;
    private final AuthenticationManager authManager;
    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;
    private final PasswordEncoder encoder;

    //user registration
    @PostMapping("/register")
    public String register(@RequestBody User user) {
        user.setPassword(encoder.encode(user.getPassword()));
        if (user.getRole() == null) {
            user.setRole(Role.USER); // fallback if role not passed
        }

        userRepository.save(user);
        return "User registered successfully!";
    }

    //user login
    @PostMapping("/login")
    public Map<String, String> login(@RequestBody UserDTO request) {
        authManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        final UserDetails user = userDetailsService.loadUserByUsername(request.getEmail());
        final String token = jwtService.generateToken(user.getUsername());


        return Map.of("token", token);
    }
    
 // ADMIN: View all users
    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // ADMIN: Delete a user by ID
    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "User deleted successfully.";
    }

}
