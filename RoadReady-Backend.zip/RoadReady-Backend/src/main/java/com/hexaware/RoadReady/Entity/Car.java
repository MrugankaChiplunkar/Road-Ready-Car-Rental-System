package com.hexaware.RoadReady.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String make;           
    private String model;          
    private int year;            
    private double pricePerDay;   
    private boolean available;     
    private String location;      
    private String imageUrl;       
}
