package com.hexaware.RoadReady.Controller;

import com.hexaware.RoadReady.DTO.CarDTO;
import com.hexaware.RoadReady.Service.CarService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/cars")
@RequiredArgsConstructor
public class CarController {

    private final CarService carService;

    // Admin: Add Car
    @PostMapping("/add")
    @PreAuthorize("hasRole('ADMIN')")
    public CarDTO addCar(@RequestBody CarDTO carDTO) {
        return carService.addCar(carDTO);
    }

    // Admin: Update Car
    @PutMapping("update/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public CarDTO updateCar(@PathVariable Long id, @RequestBody CarDTO carDTO) {
        return carService.updateCar(id, carDTO);
    }

    // Admin: Delete Car
    @DeleteMapping("delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteCar(@PathVariable Long id) {
        carService.deleteCar(id);
        return "Car with ID " + id + " deleted successfully.";
    }

    // Admin: View All Cars
    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public List<CarDTO> getAllCarsAdmin() {
        return carService.getAllCars();
    }

    // View All Available Cars (For Browsing)
    @GetMapping
    public List<CarDTO> getAllCarsPublic() {
        return carService.getAllCars(); // You can filter by `available = true` inside service if needed
    }

    // View Single Car by id
    @GetMapping("/{id}")
    public CarDTO getCarByIdPublic(@PathVariable Long id) {
        return carService.getCarById(id);
    }
}
