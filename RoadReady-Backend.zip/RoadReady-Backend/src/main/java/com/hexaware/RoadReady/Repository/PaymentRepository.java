package com.hexaware.RoadReady.Repository;

import com.hexaware.RoadReady.Entity.Booking;
import com.hexaware.RoadReady.Entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByBooking(Booking booking);
    boolean existsByBooking(Booking booking);
    List<Payment> findByUser_Email(String email); 
}
