package com.hexaware.RoadReady.Controller;

import com.hexaware.RoadReady.DTO.PaymentDTO;
import com.hexaware.RoadReady.Service.PaymentService;

import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    //process payments
    @PostMapping("/process/{bookingId}")             
    @PreAuthorize("hasRole('USER')")
    public PaymentDTO pay(@PathVariable Long bookingId,
                          @RequestParam String method) {
        return paymentService.processPayment(bookingId, method);
    }

    
    //view payments
    @GetMapping("/booking/{bookingId}")
    public PaymentDTO getPayment(@PathVariable Long bookingId) {
        return paymentService.getPaymentByBookingId(bookingId);
    }
    
    //ADMIN: view payment by booking
    @GetMapping("/admin/booking/{bookingId}")
    @PreAuthorize("hasRole('ADMIN')")
    public PaymentDTO getPaymentByBooking(@PathVariable Long bookingId) {
        return paymentService.getPaymentByBookingId(bookingId);
    }

    //ADMIN: view all payments
    @GetMapping("/admin/all")
    @PreAuthorize("hasRole('ADMIN')")
    public List<PaymentDTO> getAllPayments() {
        return paymentService.getAllPayments();
    }
    

 // USER: view all payments
 @GetMapping
 @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
 public List<PaymentDTO> getPaymentsForLoggedInUser() {
     return paymentService.getPaymentsForLoggedInUser();
 }



}
