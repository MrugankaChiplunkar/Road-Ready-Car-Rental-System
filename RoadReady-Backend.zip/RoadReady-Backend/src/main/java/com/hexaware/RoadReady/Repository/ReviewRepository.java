package com.hexaware.RoadReady.Repository;

import com.hexaware.RoadReady.Entity.Review;
import com.hexaware.RoadReady.Entity.Car;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByCar(Car car);
    
    List<Review> findByUserEmail(String email);
}
