package com.hexaware.RoadReady.Service;

import com.hexaware.RoadReady.DTO.UserProfileDTO;

import java.util.List;

public interface UserService {

    UserProfileDTO getProfile(String email);

    UserProfileDTO updateProfile(String email, UserProfileDTO dto);

    String resetPassword(String email, String oldPass, String newPass);

    List<UserProfileDTO> getAllUsers();

    void deleteUser(Long userId);
}
