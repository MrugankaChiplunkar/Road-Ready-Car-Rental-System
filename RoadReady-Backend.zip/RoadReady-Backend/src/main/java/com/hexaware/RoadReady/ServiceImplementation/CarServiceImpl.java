package com.hexaware.RoadReady.ServiceImplementation;

import com.hexaware.RoadReady.DTO.CarDTO;
import com.hexaware.RoadReady.Entity.Car;
import com.hexaware.RoadReady.Repository.CarRepository;
import com.hexaware.RoadReady.Service.CarService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final ModelMapper modelMapper;

    @Override
    public CarDTO addCar(CarDTO carDTO) {
        Car car = modelMapper.map(carDTO, Car.class);
        Car savedCar = carRepository.save(car);
        return modelMapper.map(savedCar, CarDTO.class);
    }

    @Override
    public CarDTO updateCar(Long id, CarDTO carDTO) {
        Optional<Car> optionalCar = carRepository.findById(id);
        if (optionalCar.isPresent()) {
            Car car = optionalCar.get();
            car.setMake(carDTO.getMake());
            car.setModel(carDTO.getModel());
            car.setYear(carDTO.getYear());
            car.setPricePerDay(carDTO.getPricePerDay());
            car.setAvailable(carDTO.isAvailable());
            car.setLocation(carDTO.getLocation());
            car.setImageUrl(carDTO.getImageUrl());
            return modelMapper.map(carRepository.save(car), CarDTO.class);
        }
        throw new RuntimeException("Car not found with ID: " + id);
    }

    @Override
    public void deleteCar(Long id) {
        carRepository.deleteById(id);
    }

    @Override
    public CarDTO getCarById(Long id) {
        Car car = carRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Car not found with ID: " + id));
        return modelMapper.map(car, CarDTO.class);
    }

    @Override
    public List<CarDTO> getAllCars() {
        return carRepository.findAll()
                .stream()
                .map(car -> modelMapper.map(car, CarDTO.class))
                .collect(Collectors.toList());
    }
}
