package com.hexaware.RoadReady.ServiceImplementation;

import com.hexaware.RoadReady.DTO.PaymentDTO;
import com.hexaware.RoadReady.Entity.Booking;
import com.hexaware.RoadReady.Entity.Payment;
import com.hexaware.RoadReady.Entity.User;
import com.hexaware.RoadReady.Repository.BookingRepository;
import com.hexaware.RoadReady.Repository.PaymentRepository;
import com.hexaware.RoadReady.Repository.UserRepository;
import com.hexaware.RoadReady.Service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final UserRepository userRepository;

    @Override
    public PaymentDTO processPayment(Long bookingId, String paymentMethod) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (paymentRepository.existsByBooking(booking)) {
            throw new RuntimeException("Payment already processed for this booking.");
        }

        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Payment payment = Payment.builder()
                .booking(booking)
                .user(user)
                .paymentMethod(paymentMethod)
                .amount(booking.getTotalCost())
                .paymentDate(LocalDateTime.now())
                .status("SUCCESS")
                .build();

        Payment saved = paymentRepository.save(payment);
        return mapToDTO(saved);
    }

    @Override
    public PaymentDTO getPaymentByBookingId(Long bookingId) {
        return paymentRepository.findAll().stream()
                .filter(p -> p.getBooking().getId().equals(bookingId))
                .findFirst()
                .map(this::mapToDTO)
                .orElseThrow(() -> new RuntimeException("Payment not found for booking ID: " + bookingId));
    }

    @Override
    public List<PaymentDTO> getAllPayments() {
        return paymentRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<PaymentDTO> getPaymentsForLoggedInUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        List<Payment> payments = paymentRepository.findByUser_Email(email);
        return payments.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private PaymentDTO mapToDTO(Payment payment) {
        return PaymentDTO.builder()
                .id(payment.getId())
                .paymentMethod(payment.getPaymentMethod())
                .status(payment.getStatus())
                .amount(payment.getAmount())
                .paymentDate(payment.getPaymentDate())
                .bookingId(payment.getBooking().getId())
                .build();
    }
}
