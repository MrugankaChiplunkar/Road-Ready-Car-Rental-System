package com.hexaware.RoadReady.ServiceImplementation;

import com.hexaware.RoadReady.DTO.ReviewDTO;
import com.hexaware.RoadReady.Entity.*;
import com.hexaware.RoadReady.Exception.ReviewNotFoundException;
import com.hexaware.RoadReady.Repository.*;
import com.hexaware.RoadReady.Service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepo;
    private final BookingRepository bookingRepo;
    private final CarRepository carRepo;
    private final UserRepository userRepo;
    private final ModelMapper modelMapper;

    @Override
    public ReviewDTO postReview(Long bookingId, int rating, String comment, String userEmail) {
        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        User user = userRepo.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!booking.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("You are not authorized to review this booking");
        }

        Review review = Review.builder()
                .rating(rating)
                .comment(comment)
                .postedAt(LocalDateTime.now())
                .car(booking.getCar())
                .user(user)
                .booking(booking)
                .build();

        return modelMapper.map(reviewRepo.save(review), ReviewDTO.class);
    }

    @Override
    public List<ReviewDTO> getReviewsForCar(Long carId) {
        Car car = carRepo.findById(carId)
                .orElseThrow(() -> new RuntimeException("Car not found"));

        return reviewRepo.findByCar(car).stream()
                .map(review -> modelMapper.map(review, ReviewDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ReviewDTO> getAllReviews() {
        return reviewRepo.findAll().stream()
                .map(review -> modelMapper.map(review, ReviewDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteReview(Long reviewId) {
        if (!reviewRepo.existsById(reviewId)) {
            throw new ReviewNotFoundException("Review with ID " + reviewId + " not found");
        }
        reviewRepo.deleteById(reviewId);
    }
    
    @Override
    public List<ReviewDTO> getReviewsByUser(String email) {
        List<Review> reviews = reviewRepo.findByUserEmail(email);
        return reviews.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private ReviewDTO convertToDTO(Review review) {
        ReviewDTO dto = new ReviewDTO();
        dto.setId(review.getId());
        dto.setComment(review.getComment());
        dto.setRating(review.getRating());
        dto.setPostedAt(review.getPostedAt());
        dto.setCarId(review.getCar().getId());
        dto.setBookingId(review.getBooking().getId());
        return dto;
    }


}
