package com.hexaware.RoadReady.Controller;

import com.hexaware.RoadReady.DTO.UserProfileDTO;
import com.hexaware.RoadReady.Service.UserService;
import com.hexaware.RoadReady.Repository.BookingRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final UserService userService;
    private final BookingRepository bookingRepository;

    // View Own Profile
    @GetMapping("/me")
    @PreAuthorize("hasAuthority('USER')")
    public UserProfileDTO getProfile(Authentication authentication) {
        return userService.getProfile(authentication.getName());
    }

    // Update Own Profile
    @PutMapping("/update")
    @PreAuthorize("hasAuthority('USER')")
    public UserProfileDTO updateProfile(@RequestBody UserProfileDTO dto,
                                        Authentication authentication) {
        return userService.updateProfile(authentication.getName(), dto);
    }

    // Reset Password
    @PutMapping("/reset-password")       
    @PreAuthorize("hasAuthority('USER')")
    public String resetPassword(Authentication authentication,
                                @RequestParam String oldPassword,
                                @RequestParam String newPassword) {
        return userService.resetPassword(authentication.getName(), oldPassword, newPassword);
    }

    // Admin - View All Users
    @GetMapping("/admin/all")
    @PreAuthorize("hasAuthority('ADMIN')")
    public List<UserProfileDTO> getAllUsers() {
        return userService.getAllUsers();
    }

    // Admin - Delete a User
    @DeleteMapping("/admin/delete/{userId}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> deleteUser(@PathVariable Long userId) {
        if (!bookingRepository.findByUserId(userId).isEmpty()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Cannot delete user. They have active bookings.");
        }

        userService.deleteUser(userId);
        return ResponseEntity.ok("User with ID " + userId + " deleted successfully.");
    }
}



