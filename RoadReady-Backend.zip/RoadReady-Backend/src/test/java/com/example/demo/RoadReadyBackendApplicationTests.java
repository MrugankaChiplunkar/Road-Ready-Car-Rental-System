package com.example.demo;


import com.hexaware.RoadReady.DTO.BookingDTO;
import com.hexaware.RoadReady.Entity.Booking;
import com.hexaware.RoadReady.Entity.Car;
import com.hexaware.RoadReady.Entity.Role;
import com.hexaware.RoadReady.Entity.User;
import com.hexaware.RoadReady.Exception.UserNotFoundException;
import com.hexaware.RoadReady.Repository.BookingRepository;
import com.hexaware.RoadReady.Repository.CarRepository;
import com.hexaware.RoadReady.Repository.UserRepository;
import com.hexaware.RoadReady.Service.BookingService;
import com.hexaware.RoadReady.ServiceImplementation.BookingServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.modelmapper.ModelMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceImplTest {

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private CarRepository carRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private BookingServiceImpl bookingService;

    private User mockUser;
    private Car mockCar;

    @BeforeEach
    void setupSecurityContext() {
        mockUser = User.builder().id(1L).email("test@example.com").build();
        mockCar = Car.builder().id(1L).pricePerDay(100.0).available(true).build();

        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("test@example.com");

        SecurityContext context = mock(SecurityContext.class);
        when(context.getAuthentication()).thenReturn(auth);
        SecurityContextHolder.setContext(context);
    }

    // Successful booking
    @Test
    void shouldBookCarSuccessfully() {
        BookingDTO dto = BookingDTO.builder()
                .carId(1L)
                .pickupDate(LocalDate.of(2025, 7, 20))
                .dropoffDate(LocalDate.of(2025, 7, 25))
                .build();

        when(carRepository.findById(1L)).thenReturn(Optional.of(mockCar));
        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(mockUser));
        when(bookingRepository.existsByCarAndPickupDateLessThanEqualAndDropoffDateGreaterThanEqual(
                mockCar, dto.getDropoffDate(), dto.getPickupDate())).thenReturn(false);

        Booking savedBooking = Booking.builder()
                .id(1L)
                .car(mockCar)
                .user(mockUser)
                .pickupDate(dto.getPickupDate())
                .dropoffDate(dto.getDropoffDate())
                .totalCost(500.0)
                .build();

        when(bookingRepository.save(any())).thenReturn(savedBooking);
        when(modelMapper.map(savedBooking, BookingDTO.class)).thenReturn(
                BookingDTO.builder().id(1L).totalCost(500.0).build()
        );

        BookingDTO result = bookingService.bookCar(dto);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals(500.0, result.getTotalCost());
    }

    //  Booking conflict
    @Test
    void shouldThrowExceptionIfCarAlreadyBooked() {
        BookingDTO dto = BookingDTO.builder()
                .carId(1L)
                .pickupDate(LocalDate.of(2025, 7, 20))
                .dropoffDate(LocalDate.of(2025, 7, 25))
                .build();

        when(carRepository.findById(1L)).thenReturn(Optional.of(mockCar));
        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(mockUser));
        when(bookingRepository.existsByCarAndPickupDateLessThanEqualAndDropoffDateGreaterThanEqual(
                mockCar, dto.getDropoffDate(), dto.getPickupDate())).thenReturn(true);

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            bookingService.bookCar(dto);
        });

        assertEquals("Car is already booked for the selected dates", ex.getMessage());
    }

 // User not found during booking
    @Test
    void shouldThrowExceptionIfUserNotFound() {
        BookingDTO dto = BookingDTO.builder()
                .carId(1L)
                .pickupDate(LocalDate.of(2025, 7, 20))
                .dropoffDate(LocalDate.of(2025, 7, 25))
                .build();

        when(carRepository.findById(1L)).thenReturn(Optional.of(mockCar));
        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.empty());

        UserNotFoundException ex = assertThrows(UserNotFoundException.class, () -> {
            bookingService.bookCar(dto);
        });

        assertEquals("User not found", ex.getMessage());
    }
    // Get bookings by user
    @Test
    void shouldGetBookingsByUser() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));
        when(bookingRepository.findByUser(mockUser)).thenReturn(
                List.of(Booking.builder().id(1L).car(mockCar).user(mockUser).build())
        );

        when(modelMapper.map(any(Booking.class), eq(BookingDTO.class))).thenReturn(
                BookingDTO.builder().id(1L).carId(1L).build()
        );

        var result = bookingService.getBookingsByUser(1L);

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getId());
    }

    // Cancel booking with unauthorized user
    @Test
    void shouldThrowSecurityExceptionIfUserNotAuthorizedToCancel() {
        User otherUser = User.builder().id(2L).email("other@example.com").build();
        Booking booking = Booking.builder().id(1L).user(otherUser).build();

        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(mockUser));
        mockUser.setRole(Role.USER); // assuming enum Role.USER

        SecurityException ex = assertThrows(SecurityException.class, () -> {
            bookingService.cancelBooking(1L);
        });

        assertEquals("You are not authorized to cancel this booking", ex.getMessage());
    }
}