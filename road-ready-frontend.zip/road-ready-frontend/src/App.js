// src/App.js
import React from 'react';
import AppRoutes from './AppRoutes';
import NavBar from './components/NavBar';
import './App.css'; // Optional: if not using now, remove import
import Footer from './components/Footer';

function App() {
  return (
    <div>
      <NavBar />
      <AppRoutes />
      <Footer />
    </div>
  );
}

export default App;
