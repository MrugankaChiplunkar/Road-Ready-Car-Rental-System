import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../services/Api';
import { saveToken } from '../utils/Auth';
import { jwtDecode } from 'jwt-decode';
import { Container, Form, Button, Alert, Card } from 'react-bootstrap';
import bgImage from '../assets/bg.png';

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

 const handleSubmit = async (e) => {
  e.preventDefault();
  setLoading(true);
  setError('');

  try {
    const response = await axios.post('/api/auth/login', formData);
    const { token } = response.data;

    saveToken(token);


    const decoded = jwtDecode(token);
    const roles = decoded.roles || [];


 if (roles.includes("ROLE_ADMIN") || roles.includes("ROLE_USER")) {
  navigate("/");
} else {
  navigate("/login");
}


  } catch (err) {
    setError('Invalid email or password');
  } finally {
    setLoading(false);
  }
};


  

  return (
    <div className="bg-black text-white min-vh-100 d-flex justify-content-center align-items-center py-5"
          style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        minHeight: '100vh',
        paddingTop: '5rem',
        paddingBottom: '5rem',
        color: 'white'
      }}>
      <Card style={{ width: '450px' }} className="p-4 shadow-lg bg-dark text-white border-0 rounded-4">
        <h3 className="text-center text-danger fw-bold mb-4">Login</h3>
        {error && <Alert variant="danger">{error}</Alert>}

        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="email" className="mb-3">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter email"
              required
              className="bg-black text-white border-secondary"
            />
          </Form.Group>

          <Form.Group controlId="password" className="mb-4">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Password"
              required
              className="bg-black text-white border-secondary"
            />
          </Form.Group>

          <Button type="submit" variant="danger" className="w-100 fw-semibold" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </Button>
        </Form>

        <p className="text-center mt-3 small text-red">
          Don’t have an account?{' '}
          <a href="/register" className="text-danger text-decoration-none text-center fw-bold">
            Register
          </a>
        </p>
      </Card>
    </div> 
  );
};

export default Login;
