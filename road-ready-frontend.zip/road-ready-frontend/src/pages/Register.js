
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../services/Api';
import { Container, Form, Button, Alert, Card } from 'react-bootstrap';
import bgImage from '../assets/bg.png';
const Register = () => {
const navigate = useNavigate();
const [formData, setFormData] = useState({
firstName: '',
lastName: '',
email: '',
phone: '',
password: '',
role: 'USER'
});
const [error, setError] = useState('');
const [success, setSuccess] = useState(false);
const [loading, setLoading] = useState(false);
const handleChange = e =>
setFormData({ ...formData, [e.target.name]: e.target.value });
const handleSubmit = async e => {
e.preventDefault();
setLoading(true);
setError('');
setSuccess(false);
try {
await axios.post('/api/auth/register', formData);
setSuccess(true);
setTimeout(() => navigate('/login'), 1500);
} catch (err) {
setError('Registration failed. Please try again.');
} finally {
setLoading(false);
}
};
return (
<div className="bg-black text-white min-vh-100 d-flex justify-content-center align-items-center py-5"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        minHeight: '100vh',
        paddingTop: '5rem',
        paddingBottom: '5rem',
        color: 'white'
      }}>
<Card style={{ width: '450px' }} className="p-4 shadow-lg bg-dark text-white border-0 rounded-4">
<h3 className="text-center text-danger fw-bold mb-4">Create Account</h3>
{error && <Alert variant="danger">{error}</Alert>}
{success && <Alert variant="success">Registration successful! Redirecting...</Alert>}
<Form onSubmit={handleSubmit}>
<Form.Group className="mb-3" controlId="firstName">
<Form.Label>First Name</Form.Label>
<Form.Control
type="text"
name="firstName"
value={formData.firstName}
onChange={handleChange}
required
className="bg-black text-white border-secondary"
/>
</Form.Group>
<Form.Group className="mb-3" controlId="lastName">
<Form.Label>Last Name</Form.Label>
<Form.Control
type="text"
name="lastName"
value={formData.lastName}
onChange={handleChange}
required
className="bg-black text-white border-secondary"
/>
</Form.Group>
<Form.Group className="mb-3" controlId="email">
<Form.Label>Email address</Form.Label>
<Form.Control
type="email"
name="email"
value={formData.email}
onChange={handleChange}
required
className="bg-black text-white border-secondary"
/>
</Form.Group>
<Form.Group className="mb-3" controlId="phone">
<Form.Label>Phone Number</Form.Label>
<Form.Control
type="text"
name="phone"
value={formData.phone}
onChange={handleChange}
required
className="bg-black text-white border-secondary"
/>
</Form.Group>
<Form.Group className="mb-3" controlId="password">
<Form.Label>Password</Form.Label>
<Form.Control
type="password"
name="password"
value={formData.password}
onChange={handleChange}
required
className="bg-black text-white border-secondary"
/>
</Form.Group>
<Form.Group className="mb-4" controlId="role">
<Form.Label>Register as</Form.Label>
<Form.Select
name="role"
value={formData.role}
onChange={handleChange}
required
className="bg-black text-white border-secondary"
>
<option value="USER">User</option>
<option value="ADMIN">Admin</option>
</Form.Select>
</Form.Group>
<Button
variant="danger"
type="submit"
className="w-100 fw-semibold"
disabled={loading}
>
{loading ? 'Registering...' : 'Register'}
</Button>
</Form>
<p className="text-center mt-3 small text-red">
Already have an account?{' '}
<a href="/login" className="text-danger text-decoration-none text-center fw-bold">Login</a>
</p>
</Card>
</div>
);
};
export default Register; 
