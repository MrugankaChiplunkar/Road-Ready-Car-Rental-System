
import React from 'react';
import { Button, Container, Row, Col, Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import '../App.css';

function Home() {
  const navigate = useNavigate();

const handleBookNow = () => {
  const isLoggedIn = !!localStorage.getItem("token");
  if (!isLoggedIn) {
    alert("Please login first");
  } else {
    navigate('/cars');
  }
};


  return (
    <div>
      {/* Hero Section */}
      <div className="hero-section text-white text-center d-flex align-items-center justify-content-center">
        <div>
          <h1 className="display-4 fw-bold text-shadow">WANNA RENT OUT A CAR?</h1>
          <Button size="lg" variant="danger" className="mt-4 px-4 py-2 fw-semibold" onClick={handleBookNow}>
            BOOK NOW
          </Button>
        </div>
      </div>

      {/* Trusted Partner Section */}
      <Container className="my-5">
        <Row className="align-items-center">
          <Col md={6}>
            <h3 className="text-danger fw-bold">YOUR TRUSTED PARTNER IN CAR RENTAL</h3>
            <p className="text-muted">
              RoadReady is your trusted partner in car rentals, offering a seamless and reliable experience tailored to your travel needs. With a wide selection of well-maintained vehicles, transparent pricing, and 24/7 support, we ensure every journey is smooth, safe, and stress-free. Whether for business or leisure, count on us for convenience, quality, and confidence on the road.
            </p>
            <p>
              RoadReady is your trusted partner in car rentals, offering a seamless and reliable experience tailored to your travel needs. With a wide selection of well-maintained vehicles, transparent pricing, and 24/7 support, we ensure every journey is smooth, safe, and stress-free. Whether for business or leisure, count on us for convenience, quality, and confidence on the road.
            </p>
          </Col>
          <Col md={6}>
            <img src="https://images.unsplash.com/photo-1528659997310-540c4945fa73?q=80&w=2146&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Dashboard" className="img-fluid rounded shadow" />
          </Col>
        </Row>
      </Container>

{/*  Featured Offers Section */}
<Container className="my-5">
  <h4 className="text-danger mb-4 fw-bold text-center"> HOT DEALS ON WHEELS</h4>
  <Row>
    {[
      {
        title: "Weekend Getaway Special",
        desc: "Get up to 30% off on weekend bookings across all sedans.",
        img: "https://images.unsplash.com/photo-1680929304693-c8244d0cb37d?q=80&w=1074&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
      },
      {
        title: "Long Drive Discount",
        desc: "Book for 3+ days and enjoy flat ₹1000 off. Drive far, pay less.",
        img: "https://images.unsplash.com/photo-1593755997026-5a696043db90?q=80&w=1889&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
      },
      {
        title: "Student Saver Deal",
        desc: "Valid ID? Save 20% on all hatchbacks. Budget rides for student life.",
        img: "https://media.istockphoto.com/id/912785590/photo/couple-is-buying-new-car-and-signing-the-contract.jpg?s=2048x2048&w=is&k=20&c=gcNzyr1fLwX_1YPHj5ZBmSXxmu3iwXB9A4tKbJ08ipw="
      },
      {
        title: "Luxury at Less",
        desc: "Experience luxury cars at half the price this month only!",
        img: "https://images.unsplash.com/photo-1702593829726-7b39a91425da?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
      }
    ].map((offer, i) => (
      <Col md={3} sm={6} xs={12} key={i}>
        <Card className="mb-4 shadow-sm border-0 h-100">
          <Card.Img
            variant="top"
            src={offer.img}
            alt={offer.title}
            style={{ height: '180px', objectFit: 'cover' }}
          />
          <Card.Body className="d-flex flex-column justify-content-between text-center">
            <Card.Title className="fw-bold text-danger">{offer.title}</Card.Title>
            <Card.Text className="text-muted small">{offer.desc}</Card.Text>
            <div>
              <i className="bi bi-arrow-right-circle text-danger fs-5"></i>
            </div>
          </Card.Body>
        </Card>
      </Col>
    ))}
  </Row>
</Container>


{/* Customer Reviews */}
<div className="bg-dark text-white py-5 ">
  <Container>
    <h4 className="text-danger mb-5 text-center fw-bold">WHAT OUR CUSTOMERS SAY</h4>
    <Row>
      {[
        {
          name: "Aarav Sharma",
          comment: "Fantastic service! The car was spotless and ran smoothly throughout my weekend trip.",
          img: "https://randomuser.me/api/portraits/men/32.jpg"
        },
        {
          name: "Meera Iyer",
          comment: "Loved the easy booking experience. Highly recommend Road Ready!",
          img: "https://randomuser.me/api/portraits/women/65.jpg"
        },
        {
          name: "Rohan Deshmukh",
          comment: "Affordable, reliable, and the support team was super helpful.",
          img: "https://randomuser.me/api/portraits/men/75.jpg"
        }
      ].map((review, i) => (
        <Col md={4} sm={6} xs={12} key={i}>
          <div className="p-4 bg-secondary bg-opacity-25 rounded shadow-sm h-100 text-center ">
            <img
              src={review.img}
              alt={review.name}
              className="rounded-circle mb-3"
              style={{ width: '60px', height: '60px', objectFit: 'cover' }}
            />
            <p className="fw-bold text-danger mb-1">{review.name}</p>
            <p className="small fst-italic text-light">"{review.comment}"</p>
            <i className="bi bi-star-fill text-warning"></i>
            <i className="bi bi-star-fill text-warning"></i>
            <i className="bi bi-star-fill text-warning"></i>
            <i className="bi bi-star-fill text-warning"></i>
            <i className="bi bi-star-half text-warning"></i>
          </div>
        </Col>
      ))}
    </Row>
  </Container>
</div>


      {/* Footer */}

    </div>
  );
}

export default Home;
