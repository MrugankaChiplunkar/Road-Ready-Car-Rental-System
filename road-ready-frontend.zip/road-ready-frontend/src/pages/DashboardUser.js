import React, { useEffect, useState } from 'react';
import axios from '../services/Api';
import { Container, Row, Col, Nav, Tab, Form, Button, Alert, Table, Modal } from 'react-bootstrap';
import bgImage from '../assets/bg.png';

const DashboardUser = () => {
  const [profile, setProfile] = useState({});
  const [bookings, setBookings] = useState([]);
  const [payments, setPayments] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [newReview, setNewReview] = useState({ bookingId: '', rating: '', comment: '' });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    axios.get('/api/profile/me').then(res => setProfile(res.data)).catch(() => setError("Error loading profile"));
    axios.get('/api/bookings/user').then(res => setBookings(res.data));
    axios.get('/api/payments').then(res => setPayments(res.data));
    axios.get('/api/reviews/me').then(res => setReviews(res.data));
  };

  const handleProfileUpdate = (e) => {
    e.preventDefault();
    axios.put('/api/profile/update', profile)
      .then(() => {
        setSuccessMsg("Profile updated");
        setEditMode(false);
        fetchData();
      })
      .catch(() => setError("Failed to update profile"));
  };

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleReviewSubmit = () => {
    axios.post(`/api/reviews/post/${newReview.bookingId}`, {
      rating: newReview.rating,
      comment: newReview.comment
    })
      .then(() => {
        setShowReviewModal(false);
        setNewReview({ bookingId: '', rating: '', comment: '' });
        fetchData();
      })
      .catch(() => setError("Failed to submit review"));
  };

  const deleteReview = (id) => {
    axios.delete(`/api/reviews/${id}`).then(() => fetchData()).catch(() => setError("Failed to delete review"));
  };

  return (
    <div className="bg-black text-white py-5 min-vh-100"      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        minHeight: '100vh',
        paddingTop: '5rem',
        paddingBottom: '5rem',
        color: 'white'
      }}
    >
      <Container>
        <h3 className="text-center text-danger fw-bold mb-4">User Dashboard</h3>

        <Tab.Container defaultActiveKey="profile">
          <Row>
            <Col sm={3}>
              <Nav variant="pills" className="flex-column bg-dark p-3 rounded shadow-sm">
                <Nav.Item><Nav.Link eventKey="profile" className="text-white">Profile</Nav.Link></Nav.Item>
                <Nav.Item><Nav.Link eventKey="bookings" className="text-white">Bookings</Nav.Link></Nav.Item>
                <Nav.Item><Nav.Link eventKey="payments" className="text-white">Payments</Nav.Link></Nav.Item>
                <Nav.Item><Nav.Link eventKey="reviews" className="text-white">Reviews</Nav.Link></Nav.Item>
              </Nav>
            </Col>

            <Col sm={9}>
              <Tab.Content>
                <Tab.Pane eventKey="profile">
                  {successMsg && <Alert variant="success">{successMsg}</Alert>}
                  {error && <Alert variant="danger">{error}</Alert>}
                  <Form onSubmit={handleProfileUpdate} className="bg-dark p-4 rounded shadow-sm">
                    {['firstName', 'lastName', 'email', 'phone'].map(field => (
                      <Form.Group className="mb-3" key={field}>
                        <Form.Label className="text-white">{field.replace(/^[a-z]/, c => c.toUpperCase())}</Form.Label>
                        {editMode ? (
                          <Form.Control type="text" name={field} value={profile[field] || ''} onChange={handleChange} />
                        ) : (
                          <Form.Control plaintext readOnly defaultValue={profile[field] || ''} className="text-white" />
                        )}
                      </Form.Group>
                    ))}
                    {editMode ? (
                      <>
                        <Button variant="success" type="submit" className="me-2">Save</Button>
                        <Button variant="secondary" onClick={() => setEditMode(false)}>Cancel</Button>
                      </>
                    ) : (
                      <Button variant="danger" onClick={() => setEditMode(true)}>Edit Profile</Button>
                    )}
                  </Form>
                </Tab.Pane>

                <Tab.Pane eventKey="bookings">
                  <h5 className="text-danger mt-4 mb-3"> Your Bookings</h5>
                  <Table striped bordered hover variant="dark">
                    <thead><tr><th>ID</th><th>Pickup</th><th>Dropoff</th><th>Cost</th></tr></thead>
                    <tbody>{bookings.map(b => (
                      <tr key={b.id}><td>{b.id}</td><td>{b.pickupDate}</td><td>{b.dropoffDate}</td><td>₹{b.totalCost}</td></tr>
                    ))}</tbody>
                  </Table>
                </Tab.Pane>

                <Tab.Pane eventKey="payments">
                  <h5 className="text-danger mt-4 mb-3"> Your Payments</h5>
                  <Table striped bordered hover variant="dark">
                    <thead><tr><th>ID</th><th>Booking</th><th>Amount</th><th>Date</th><th>Method</th><th>Status</th></tr></thead>
                    <tbody>{payments.map(p => (
                      <tr key={p.id}><td>{p.id}</td><td>{p.bookingId}</td><td>₹{p.amount}</td><td>{new Date(p.paymentDate).toLocaleString()}</td><td>{p.paymentMethod}</td><td>{p.status}</td></tr>
                    ))}</tbody>
                  </Table>
                </Tab.Pane>

                <Tab.Pane eventKey="reviews">
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <h5 className="text-danger">Your Reviews</h5>
                    <Button variant="danger" size="sm" onClick={() => setShowReviewModal(true)}>+ Add Review</Button>
                  </div>
                  <ul className="list-group">
                    {reviews.map(r => (
                      <li className="list-group-item bg-dark text-white border-secondary" key={r.id}>
                        <strong>Booking:</strong> #{r.bookingId} | {r.rating}/5 <br />
                        <em>{r.comment}</em><br />
                        <small>{new Date(r.postedAt).toLocaleString()}</small>
                        <Button variant="outline-danger" size="sm" className="float-end" onClick={() => deleteReview(r.id)}>Delete</Button>
                      </li>
                    ))}
                  </ul>
                </Tab.Pane>
              </Tab.Content>
            </Col>
          </Row>
        </Tab.Container>

        <Modal show={showReviewModal} onHide={() => setShowReviewModal(false)} centered>
          <Modal.Header closeButton className="bg-dark text-white">
            <Modal.Title>Add Review</Modal.Title>
          </Modal.Header>
          <Modal.Body className="bg-dark text-white">
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Select Booking</Form.Label>
                <Form.Select
                  value={newReview.bookingId}
                  onChange={e => setNewReview({ ...newReview, bookingId: e.target.value })}
                >
                  <option value="">-- Select Booking --</option>
                  {bookings.map(b => (
                    <option key={b.id} value={b.id}>
                      #{b.id} - {b.pickupDate} to {b.dropoffDate}
                    </option>
                  ))}
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Rating (1-5)</Form.Label>
                <Form.Control
                  type="number"
                  value={newReview.rating}
                  onChange={e => setNewReview({ ...newReview, rating: e.target.value })}
                  min="1" max="5"
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Comment</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  value={newReview.comment}
                  onChange={e => setNewReview({ ...newReview, comment: e.target.value })}
                />
              </Form.Group>
            </Form>
          </Modal.Body>
          <Modal.Footer className="bg-dark">
            <Button variant="secondary" onClick={() => setShowReviewModal(false)}>Cancel</Button>
            <Button variant="danger" onClick={handleReviewSubmit}>Submit</Button>
          </Modal.Footer>
        </Modal>
      </Container>
    </div>
  );
};

export default DashboardUser;







