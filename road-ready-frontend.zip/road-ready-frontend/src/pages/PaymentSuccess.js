import React, { useEffect } from 'react';
import { Container, Alert } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import bgImage from '../assets/bg.png';

const PaymentSuccess = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/dashboard');
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="bg-black text-white min-vh-100 d-flex justify-content-center align-items-center"
          style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        minHeight: '100vh',
        paddingTop: '5rem',
        paddingBottom: '5rem',
        color: 'white'
      }}>
      <Container className="text-center">
        <Alert variant="success" className="shadow-lg p-5 fs-5">
          <h4 className="text-success fw-bold">Payment Successful!</h4>
          <p className="text-muted mt-3">Redirecting to your dashboard...</p>
        </Alert>
      </Container>
    </div>
  );
};

export default PaymentSuccess;
