import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from '../services/Api';
import { Container, Form, Button, Alert, Row, Col, Spinner, Card } from 'react-bootstrap';
import bgImage from '../assets/bg.png';
import '../App.css'

const Booking = () => {
  const { carId } = useParams();
  const [car, setCar] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    pickupDate: '',
    dropoffDate: '',
    pickupTime: '',
    dropoffTime: '',
    pickupAddress: '',
    dropoffAddress: '',
    duration: ''
  });

  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`/api/cars/${carId}`)
      .then(res => setCar(res.data))
      .catch(() => setError("Car data not found"))
      .finally(() => setLoading(false));
  }, [carId]);

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleBooking = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }

    try {
      const payload = {
        pickupDate: formData.pickupDate,
        dropoffDate: formData.dropoffDate,
        carId: Number(carId)
      };

      const res = await axios.post('/api/bookings', payload);
      const newBooking = res.data;

      setSuccessMsg('Booking successful! Redirecting to payment...');
      setTimeout(() => navigate(`/payment/${newBooking.id}`), 2000);
    } catch (err) {
      setError(err.response?.data || 'Booking failed');
    }
  };

  if (loading) {
    return (
      <Container className="text-center my-5">
        <Spinner animation="border" variant="danger" />
      </Container>
    );
  }

  return (
    <div className="bg-black text-white py-5 min-vh-100"
          style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        minHeight: '100vh',
        paddingTop: '5rem',
        paddingBottom: '5rem',
        color: 'white'
      }}>
      <Container>
        <Row className="align-items-start">
          {/* Car Detail Section */}
          <Col md={5}>
            <Card className="bg-dark text-white shadow border-0 mb-4">
              <Card.Img
                variant="top"
                src={car.imageUrl || 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80'}
                style={{ height: '260px', objectFit: 'cover' }}
              />
              <Card.Body>
                <Card.Title className="text-danger text-center">{car.make} {car.model}</Card.Title>
                <Card.Text className="small text-center">
                  Year: {car.year} | Location: {car.location}<br />
                  Price/Day: ₹{car.pricePerDay}<br />
                  Status: {car.available ? 'Available' : 'Not Available'}
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>

          {/* Form Section */}
          <Col md={7}>
            <h3 className="text-danger mb-4 text-center">Book Your Ride!</h3>
            {error && <Alert variant="danger">{error}</Alert>}
            {successMsg && <Alert variant="success">{successMsg}</Alert>}

            <Form onSubmit={handleBooking}>
              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label className="text-white date-input">Pickup Date</Form.Label>
                    <Form.Control
                      type="date"
                      name="pickupDate"
                      value={formData.pickupDate}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label className="text-white date-input">Dropoff Date</Form.Label>
                    <Form.Control
                      type="date"
                      name="dropoffDate"
                      value={formData.dropoffDate}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label className="text-white time-input">Pickup Time</Form.Label>
                    <Form.Control
                      type="time"
                      name="pickupTime"
                      value={formData.pickupTime}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label className="text-white time-input">Dropoff Time</Form.Label>
                    <Form.Control
                      type="time"
                      name="dropoffTime"
                      value={formData.dropoffTime}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label className="text-white">Pickup Address</Form.Label>
                    <Form.Control
                      type="text"
                      name="pickupAddress"
                      value={formData.pickupAddress}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label className="text-white">Dropoff Address</Form.Label>
                    <Form.Control
                      type="text"
                      name="dropoffAddress"
                      value={formData.dropoffAddress}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group className="mb-4">
                    <Form.Label className="text-white">Duration (in hours)</Form.Label>
                    <Form.Control
                      type="number"
                      name="duration"
                      value={formData.duration}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Col>
              </Row>

              <div className="text-center">
                <Button variant="danger" type="submit" className="px-4 py-2 fw-semibold">
                  Confirm Booking
                </Button>
              </div>
            </Form>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Booking;

