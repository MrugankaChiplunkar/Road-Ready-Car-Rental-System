import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../services/Api';
import {
  Container,
  Form,
  Button,
  Alert,
  Spinner,
  Card,
  Modal,
  Row,
  Col
} from 'react-bootstrap';
import bgImage from '../assets/bg.png';

const Payment = () => {
  const { bookingId } = useParams();
  const navigate = useNavigate();

  const [booking, setBooking] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('CREDIT_CARD');
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [confirmModal, setConfirmModal] = useState(false);


  const [cardInfo, setCardInfo] = useState({
    firstName: '',
    lastName: '',
    cardNumber: '',
    cvv: '',
    expiry: ''
  });

  useEffect(() => {
    axios.get(`/api/bookings/${bookingId}`)
      .then(res => setBooking(res.data))
      .catch(() => setError("Failed to load booking"))
      .finally(() => setLoading(false));
  }, [bookingId]);

  const handlePayment = async () => {
    setError('');
    setProcessing(true);
    try {
      await axios.post(`/api/payments/process/${bookingId}`, null, {
        params: { method: paymentMethod }
      });
      setSuccessMsg("Payment successful! Redirecting...");
      setTimeout(() => navigate('/payment-success'), 1500);
    } catch (err) {
      setError(err.response?.data || "Payment failed.");
    } finally {
      setProcessing(false);
      setConfirmModal(false);
    }
  };

  if (loading) {
    return (
      <Container className="text-center my-5">
        <Spinner animation="border" variant="danger" />
      </Container>
    );
  }

  if (!booking) {
    return (
      <Container className="text-center my-5">
        <Alert variant="danger">Booking not found. Please try again.</Alert>
      </Container>
    );
  }

  return (
    <div className="bg-black text-white py-5 min-vh-100"
          style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        minHeight: '100vh',
        paddingTop: '5rem',
        paddingBottom: '5rem',
        color: 'white'
      }}>
      <Container>
        <Card className="bg-dark text-white shadow p-4 border-0 mx-auto" style={{ maxWidth: '800px' }}>
          <h3 className="text-danger text-center mb-4">💳 Payment</h3>
          <p className="text-center"><strong>Total Cost:</strong> ₹{booking.totalCost}</p>

          {error && <Alert variant="danger">{error}</Alert>}
          {successMsg && <Alert variant="success">{successMsg}</Alert>}

          <Row>
            {/* Left - Card Form */}
            <Col md={6}>
              <Form>
                <Form.Group className="mb-3">
                  <Form.Label>First Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter first name"
                    value={cardInfo.firstName}
                    onChange={(e) => setCardInfo({ ...cardInfo, firstName: e.target.value })}
                    className="bg-black text-white border-secondary"
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Last Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter last name"
                    value={cardInfo.lastName}
                    onChange={(e) => setCardInfo({ ...cardInfo, lastName: e.target.value })}
                    className="bg-black text-white border-secondary"
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Credit Card No</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="1234 5678 9012 3456"
                    value={cardInfo.cardNumber}
                    onChange={(e) => setCardInfo({ ...cardInfo, cardNumber: e.target.value })}
                    className="bg-black text-white border-secondary"
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>CVV</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="***"
                    value={cardInfo.cvv}
                    onChange={(e) => setCardInfo({ ...cardInfo, cvv: e.target.value })}
                    className="bg-black text-white border-secondary"
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Card Expiration</Form.Label>
                  <Form.Control
                    type="month"
                    value={cardInfo.expiry}
                    onChange={(e) => setCardInfo({ ...cardInfo, expiry: e.target.value })}
                    className="bg-black text-white border-secondary"
                  />
                </Form.Group>
              </Form>
            </Col>

          
            <Col md={6}>
              <Form>
                <Form.Group className="mb-4">
                  <Form.Label>Select Payment Method</Form.Label>
                  <Form.Select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="bg-black text-white border-secondary"
                  >
                    <option value="CREDIT_CARD">Credit Card</option>
                    <option value="DEBIT_CARD">Debit Card</option>
                  </Form.Select>
                </Form.Group>

                <Button
                  type="button"
                  variant="danger"
                  disabled={processing}
                  className="w-100 fw-semibold"
                  onClick={() => setConfirmModal(true)}
                >
                  {processing ? 'Processing...' : 'Confirm & Pay'}
                </Button>
              </Form>
            </Col>
          </Row>
        </Card>
      </Container>

      {/* Confirm Payment Modal */}
      <Modal show={confirmModal} onHide={() => setConfirmModal(false)} centered>
        <Modal.Header closeButton className="bg-dark text-white">
          <Modal.Title>Confirm Payment</Modal.Title>
        </Modal.Header>
        <Modal.Body className="bg-dark text-white">
          Are you sure you want to proceed with this payment of ₹{booking.totalCost}?
        </Modal.Body>
        <Modal.Footer className="bg-dark">
          <Button variant="secondary" onClick={() => setConfirmModal(false)}>Cancel</Button>
          <Button variant="danger" onClick={handlePayment} disabled={processing}>
            {processing ? 'Paying...' : 'Yes, Pay Now'}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Payment;

