import React, { useEffect, useState } from 'react';
import axios from '../services/Api';
import {
  Container, Row, Col, Tab, Nav, Table,
  Button, Alert, Modal, Form
} from 'react-bootstrap';
import bgImage from '../assets/bg.png';

const DashboardAdmin = () => {
  const [users, setUsers] = useState([]);
  const [cars, setCars] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [payments, setPayments] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [error, setError] = useState('');

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [showAddCarModal, setShowAddCarModal] = useState(false);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newCar, setNewCar] = useState({ make: '', model: '', year: '', pricePerDay: '', available: true, location: '', imageUrl: '' });
  const [newUser, setNewUser] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '', role: 'USER' });

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = () => {
    axios.get('/api/profile/admin/all').then(res => setUsers(res.data)).catch(() => setError("Failed to load users"));
    axios.get('/api/cars/admin').then(res => setCars(res.data)).catch(() => setError("Failed to load cars"));
    axios.get('/api/bookings/admin/all')
      .then(res => setBookings(res.data))
      .catch(err => {
        console.error("Bookings API Error:", err.response?.status, err.response?.data);
        setError("Failed to load bookings");
      });
    axios.get('/api/payments/admin/all')
      .then(res => setPayments(res.data))
      .catch(err => {
        console.error("Payments API Error:", err.response?.status, err.response?.data);
        setError("Failed to load payments");
      });
    axios.get('/api/reviews/admin/all')
      .then(res => setReviews(res.data))
      .catch(err => {
        console.error("Reviews API Error:", err.response?.status, err.response?.data);
        setError("Failed to load reviews");
      });
  };

  const handleAddUser = () => setShowAddUserModal(true);
  const handleAddCar = () => setShowAddCarModal(true);

  const handleCreateCar = () => {
    axios.post('/api/cars/add', newCar)
      .then(() => {
        setShowAddCarModal(false);
        setNewCar({ make: '', model: '', year: '', pricePerDay: '', available: true, location: '', imageUrl: '' });
        fetchAllData();
      })
      .catch(() => setError("Failed to add car"));
  };

  const handleCreateUser = () => {
    axios.post('/api/auth/register', newUser)
      .then(() => {
        setShowAddUserModal(false);
        setNewUser({ firstName: '', lastName: '', email: '', phone: '', password: '', role: 'USER' });
        fetchAllData();
      })
      .catch(() => setError("Failed to add user"));
  };

  const handleConfirmDelete = () => {
    if (!deleteTarget) return;
    const { type, id } = deleteTarget;
    const url = type === 'user' ? `/api/profile/admin/delete/${id}` : `/api/cars/delete/${id}`;
    axios.delete(url)
      .then(() => {
        fetchAllData();
        setShowDeleteModal(false);
        setDeleteTarget(null);
      })
      .catch((error) => {
        setError(`Failed to delete ${type}: ${error?.response?.data || 'Unknown error'}`);
        setShowDeleteModal(false);
        setDeleteTarget(null);
      });
  };

  const deleteReview = (id) => {
    axios.delete(`/api/reviews/${id}`).then(() => fetchAllData()).catch(() => setError("Failed to delete review"));
  };

  const getUserName = id => {
    const user = users.find(u => u.id === id);
    return user ? `${user.firstName} ${user.lastName}` : 'Unknown';
  };

  const getCarName = id => {
    const car = cars.find(c => c.id === id);
    return car ? `${car.make} ${car.model}` : 'Unknown';
  };

  return (
    <div className="text-white py-5 min-vh-100"
          style={{
            backgroundImage: `url(${bgImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            minHeight: '100vh',
            paddingTop: '5rem',
            paddingBottom: '5rem',
            color: 'white'
          }}>
    <Container className="text-white py-5">
      <h3 className="text-center text-danger mb-4">Admin Dashboard</h3>
      {error && <Alert variant="danger">{error}</Alert>}

      <Tab.Container defaultActiveKey="users">
        <Row>
<Col sm={3}>
               <Nav variant="pills" className="flex-column bg-dark p-3 rounded shadow-sm">
                 <Nav.Item><Nav.Link eventKey="users" className="text-white">Users</Nav.Link></Nav.Item>
                 <Nav.Item><Nav.Link eventKey="cars" className="text-white">Cars</Nav.Link></Nav.Item>
                 <Nav.Item><Nav.Link eventKey="bookings" className="text-white">Bookings</Nav.Link></Nav.Item>
                 <Nav.Item><Nav.Link eventKey="payments" className="text-white">Payments</Nav.Link></Nav.Item>
                 <Nav.Item><Nav.Link eventKey="reviews" className="text-white">Reviews</Nav.Link></Nav.Item>
               </Nav>
            </Col>
          <Col sm={9}>
            <Tab.Content>
              <Tab.Pane eventKey="users">
                <div className="d-flex justify-content-end">
                  <Button variant="danger" onClick={handleAddUser}>+ Add User</Button>
                </div>
                <Table striped bordered hover variant="dark" className="mt-3">
                  <thead>
                    <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {users.map(user => (
                      <tr key={user.id}>
                        <td>{user.id}</td>
                        <td>{user.firstName} {user.lastName}</td>
                        <td>{user.email}</td>
                        <td>{user.phone}</td>
                        <td><Button variant="danger" size="sm" onClick={() => { setDeleteTarget({ type: 'user', id: user.id }); setShowDeleteModal(true); }}>Delete</Button></td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Tab.Pane>

              <Tab.Pane eventKey="cars">
                <div className="d-flex justify-content-end">
                  <Button variant="danger" onClick={handleAddCar}>+ Add Car</Button>
                </div>
                <Table striped bordered hover variant="dark" className="mt-3">
                  <thead>
                    <tr><th>ID</th><th>Make</th><th>Model</th><th>Year</th><th>Price</th><th>Location</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {cars.map(car => (
                      <tr key={car.id}>
                        <td>{car.id}</td>
                        <td>{car.make}</td>
                        <td>{car.model}</td>
                        <td>{car.year}</td>
                        <td>₹{car.pricePerDay}</td>
                        <td>{car.location}</td>
                        <td><Button variant="danger" size="sm" onClick={() => { setDeleteTarget({ type: 'car', id: car.id }); setShowDeleteModal(true); }}>Delete</Button></td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Tab.Pane>

              <Tab.Pane eventKey="bookings">
                <Table striped bordered hover variant="dark">
                  <thead>
                    <tr><th>ID</th><th>User</th><th>Car</th><th>Pickup</th><th>Dropoff</th><th>Cost</th></tr>
                  </thead>
                  <tbody>
                      {bookings.map(b => (
                      <tr key={b.id}>
                        <td>{b.id}</td>
                        <td>{b.user?.firstName} {b.user?.lastName}</td>
                        <td>{b.car?.make} {b.car?.model}</td>
                        <td>{b.pickupDate}</td>
                        <td>{b.dropoffDate}</td>
                        <td>₹{b.totalCost}</td>
                      </tr>
                    ))}

                  </tbody>
                </Table>
              </Tab.Pane>

              <Tab.Pane eventKey="payments">
                <Table striped bordered hover variant="dark">
                  <thead>
                    <tr><th>ID</th><th>Booking</th><th>Amount</th><th>Date</th><th>Method</th><th>Status</th></tr>
                  </thead>
                  <tbody>
                    {payments.map(p => (
                      <tr key={p.id}>
                        <td>{p.id}</td>
                        <td>{p.bookingId}</td>
                        <td>₹{p.amount}</td>
                        <td>{new Date(p.paymentDate).toLocaleDateString()}</td>
                        <td>{p.paymentMethod}</td>
                        <td>{p.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Tab.Pane>

              <Tab.Pane eventKey="reviews">
                <Table striped bordered hover variant="dark">
                  <thead>
                    <tr><th>ID</th><th>User</th><th>Car</th><th>Rating</th><th>Comment</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {reviews.map(r => (
                      <tr key={r.id}>
                        <td>{r.id}</td>
                        <td>{getUserName(r.userId)}</td>
                        <td>{getCarName(r.carId)}</td>
                        <td>{r.rating}</td>
                        <td>{r.comment}</td>
                        <td><Button variant="danger" size="sm" onClick={() => deleteReview(r.id)}>Delete</Button></td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>

      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
        <Modal.Header closeButton className="bg-dark text-white">
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body className="bg-dark text-white">
          Are you sure you want to delete this {deleteTarget?.type}?
        </Modal.Body>
        <Modal.Footer className="bg-dark">
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleConfirmDelete}>Yes, Delete</Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showAddCarModal} onHide={() => setShowAddCarModal(false)} centered>
        <Modal.Header closeButton className="bg-dark text-white">
          <Modal.Title>Add Car</Modal.Title>
        </Modal.Header>
        <Modal.Body className="bg-dark text-white">
          <Form>
            <Form.Group><Form.Label>Make</Form.Label><Form.Control type="text" onChange={e => setNewCar({ ...newCar, make: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Model</Form.Label><Form.Control type="text" onChange={e => setNewCar({ ...newCar, model: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Year</Form.Label><Form.Control type="number" onChange={e => setNewCar({ ...newCar, year: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Price Per Day</Form.Label><Form.Control type="number" onChange={e => setNewCar({ ...newCar, pricePerDay: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Location</Form.Label><Form.Control type="text" onChange={e => setNewCar({ ...newCar, location: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Image URL</Form.Label><Form.Control type="text" placeholder="https://example.com/image.jpg" onChange={e => setNewCar({ ...newCar, imageUrl: e.target.value })} />
</Form.Group>

          </Form>
        </Modal.Body>
        <Modal.Footer className="bg-dark">
          <Button variant="secondary" onClick={() => setShowAddCarModal(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleCreateCar}>Add Car</Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showAddUserModal} onHide={() => setShowAddUserModal(false)} centered>
        <Modal.Header closeButton className="bg-dark text-white">
          <Modal.Title>Add User</Modal.Title>
        </Modal.Header>
        <Modal.Body className="bg-dark text-white">
          <Form>
            <Form.Group><Form.Label>First Name</Form.Label><Form.Control type="text" onChange={e => setNewUser({ ...newUser, firstName: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Last Name</Form.Label><Form.Control type="text" onChange={e => setNewUser({ ...newUser, lastName: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Email</Form.Label><Form.Control type="email" onChange={e => setNewUser({ ...newUser, email: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Phone</Form.Label><Form.Control type="text" onChange={e => setNewUser({ ...newUser, phone: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Password</Form.Label><Form.Control type="password" onChange={e => setNewUser({ ...newUser, password: e.target.value })} /></Form.Group>
            <Form.Group><Form.Label>Role</Form.Label><Form.Select onChange={e => setNewUser({ ...newUser, role: e.target.value })}>
              <option value="USER">User</option>
              <option value="ADMIN">Admin</option>
            </Form.Select></Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer className="bg-dark">
          <Button variant="secondary" onClick={() => setShowAddUserModal(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleCreateUser}>Add User</Button>
        </Modal.Footer>
      </Modal>
    </Container>
    </div>
  );
};

export default DashboardAdmin;



























// import React, { useEffect, useState } from 'react';
// import axios from '../services/Api';
// import {
//   Container, Row, Col, Tab, Nav, Table,
//   Button, Alert, Modal
// } from 'react-bootstrap';

// const DashboardAdmin = () => {
//   const [users, setUsers] = useState([]);
//   const [cars, setCars] = useState([]);
//   const [bookings, setBookings] = useState([]);
//   const [payments, setPayments] = useState([]);
//   const [reviews, setReviews] = useState([]);
//   const [error, setError] = useState('');

//   const [showDeleteModal, setShowDeleteModal] = useState(false);
//   const [deleteTarget, setDeleteTarget] = useState(null); // { type, id }

//   useEffect(() => {
//     fetchAllData();
//   }, []);

//   const fetchAllData = () => {
//     axios.get('/api/profile/admin/all')
//       .then(res => setUsers(res.data))
//       .catch(() => setError("Failed to load users"));

//     axios.get('/api/cars/admin')
//       .then(res => setCars(res.data))
//       .catch(() => setError("Failed to load cars"));

//     axios.get('/api/bookings/admin/all')
//       .then(res => setBookings(res.data))
//       .catch(() => setError("Failed to load bookings"));

//     axios.get('/api/payments/admin/all')
//       .then(res => setPayments(res.data))
//       .catch(() => setError("Failed to load payments"));

//     axios.get('/api/reviews/admin/all')
//       .then(res => setReviews(res.data))
//       .catch(() => setError("Failed to load reviews"));
//   };

//   const handleAddUser = () => {
//     alert("Add User Modal or Redirect");
//   };

//   const handleAddCar = () => {
//     alert("Add Car Modal or Redirect");
//   };

//   const handleConfirmDelete = () => {
//     const { type, id } = deleteTarget;
//     const url = type === 'user'
//       ? `/api/profile/admin/delete/${id}`
//       : `/api/cars/${id}`;

//     axios.delete(url)
//       .then(() => {
//         fetchAllData();
//         setShowDeleteModal(false);
//         setDeleteTarget(null);
//       })
//       .catch(() => {
//         setError(`Failed to delete ${type}`);
//         setShowDeleteModal(false);
//       });
//   };

//   const deleteReview = (id) => {
//     axios.delete(`/api/reviews/${id}`)
//       .then(() => fetchAllData())
//       .catch(() => setError("Failed to delete review"));
//   };

//   return (
//     <div className="bg-black text-white py-5 min-vh-100">
//       <Container>
//         <h3 className="text-danger text-center fw-bold mb-4">Admin Dashboard</h3>
//         {error && <Alert variant="danger">{error}</Alert>}

//         <Tab.Container defaultActiveKey="users">
//           <Row>
//             <Col sm={3}>
//               <Nav variant="pills" className="flex-column bg-dark p-3 rounded">
//                 <Nav.Item><Nav.Link eventKey="users" className="text-white">Users</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="cars" className="text-white">Cars</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="bookings" className="text-white">Bookings</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="payments" className="text-white">Payments</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="reviews" className="text-white">Reviews</Nav.Link></Nav.Item>
//               </Nav>
//             </Col>

//             <Col sm={9}>
//               <Tab.Content>

//                 <Tab.Pane eventKey="users">
//                   <div className="d-flex justify-content-between mb-3">
//                     <h5 className="text-danger">All Users</h5>
//                     <Button variant="outline-danger" size="sm" onClick={handleAddUser}>+ Add User</Button>
//                   </div>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {users.map(user => (
//                         <tr key={user.id}>
//                           <td>{user.id}</td>
//                           <td>{user.firstName} {user.lastName}</td>
//                           <td>{user.email}</td>
//                           <td>{user.phone}</td>
//                           <td>{user.role}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => {
//                               setDeleteTarget({ type: 'user', id: user.id });
//                               setShowDeleteModal(true);
//                             }}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 <Tab.Pane eventKey="cars">
//                   <div className="d-flex justify-content-between mb-3">
//                     <h5 className="text-danger">All Cars</h5>
//                     <Button variant="outline-danger" size="sm" onClick={handleAddCar}>+ Add Car</Button>
//                   </div>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th><th>Make</th><th>Model</th><th>Year</th><th>Price/Day</th><th>Available</th><th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {cars.map(car => (
//                         <tr key={car.id}>
//                           <td>{car.id}</td>
//                           <td>{car.make}</td>
//                           <td>{car.model}</td>
//                           <td>{car.year}</td>
//                           <td>₹{car.pricePerDay}</td>
//                           <td>{car.available ? "Yes" : "No"}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => {
//                               setDeleteTarget({ type: 'car', id: car.id });
//                               setShowDeleteModal(true);
//                             }}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 <Tab.Pane eventKey="bookings">
//                   <h5 className="text-danger">All Bookings</h5>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th><th>User ID</th><th>Car ID</th><th>Pickup</th><th>Dropoff</th><th>Cost</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {bookings.map(b => (
//                       <tr key={b.id}>
//                         <td>{b.id}</td>
//                         <td>{b.user?.firstName} {b.user?.lastName}</td>
//                         <td>{b.car?.make} {b.car?.model}</td>
//                         <td>{b.pickupDate}</td>
//                         <td>{b.dropoffDate}</td>
//                         <td>₹{b.totalCost}</td>
//                       </tr>
//                     ))}

//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 <Tab.Pane eventKey="payments">
//                   <h5 className="text-danger">All Payments</h5>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th><th>Booking ID</th><th>Method</th><th>Status</th><th>Amount</th><th>Date</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {payments.map(p => (
//                         <tr key={p.id}>
//                           <td>{p.id}</td>
//                           <td>{p.bookingId}</td>
//                           <td>{p.paymentMethod}</td>
//                           <td>{p.status}</td>
//                           <td>₹{p.amount}</td>
//                           <td>{new Date(p.paymentDate).toLocaleString()}</td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 <Tab.Pane eventKey="reviews">
//                   <h5 className="text-danger">All Reviews</h5>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th><th>User</th><th>Car</th><th>Rating</th><th>Comment</th><th>Date</th><th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {reviews.map(r => (
//                         <tr key={r.id}>
//                           <td>{r.id}</td>
//                           <td>{r.userId}</td>
//                           <td>{r.carId}</td>
//                           <td>{r.rating}</td>
//                           <td>{r.comment}</td>
//                           <td>{new Date(r.postedAt).toLocaleString()}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => deleteReview(r.id)}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//               </Tab.Content>
//             </Col>
//           </Row>
//         </Tab.Container>
//       </Container>

//       {/* Delete Modal */}
//       <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered backdrop="static">
//         <Modal.Header closeButton className="bg-dark text-white">
//           <Modal.Title>Confirm Deletion</Modal.Title>
//         </Modal.Header>
//         <Modal.Body className="bg-dark text-white">
//           Are you sure you want to delete this {deleteTarget?.type}?
//         </Modal.Body>
//         <Modal.Footer className="bg-dark">
//           <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
//           <Button variant="danger" onClick={handleConfirmDelete}>Yes, Delete</Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// };

// export default DashboardAdmin;

































// import React, { useEffect, useState } from 'react';
// import axios from '../services/Api';
// import { Container, Row, Col, Tab, Nav, Table, Button, Alert } from 'react-bootstrap';

// const DashboardAdmin = () => {
//   const [users, setUsers] = useState([]);
//   const [cars, setCars] = useState([]);
//   const [bookings, setBookings] = useState([]);
//   const [payments, setPayments] = useState([]);
//   const [reviews, setReviews] = useState([]);
//   const [error, setError] = useState('');

//   useEffect(() => {
//     fetchAllData();
//   }, []);

//   const fetchAllData = () => {
//     axios.get('/api/profile/admin/all')
//       .then(res => setUsers(res.data))
//       .catch(() => setError("Failed to load users"));

//     axios.get('/api/cars/admin')
//       .then(res => setCars(res.data))
//       .catch(() => setError("Failed to load cars"));

//     axios.get('/api/bookings/admin/all')
//       .then(res => setBookings(res.data))
//       .catch(() => setError("Failed to load bookings"));

//     axios.get('/api/payments/admin/all')
//       .then(res => setPayments(res.data))
//       .catch(() => setError("Failed to load payments"));

//     axios.get('/api/reviews/admin/all')
//       .then(res => setReviews(res.data))
//       .catch(() => setError("Failed to load reviews"));
//   };

//   const deleteUser = (id) => {
//     axios.delete(`/api/profile/admin/delete/${id}`)
//       .then(() => fetchAllData())
//       .catch(() => setError("Failed to delete user"));
//   };

//   const deleteCar = (id) => {
//     axios.delete(`/api/cars/delete/${id}`)
//       .then(() => fetchAllData())
//       .catch(() => setError("Failed to delete car"));
//   };


//   const deleteReview = (id) => {
//     axios.delete(`/api/reviews/${id}`)
//       .then(() => fetchAllData())
//       .catch(() => setError("Failed to delete review"));
//   };

//   const handleAddCar = () => {
//     alert("Redirect to Add Car Page or Show Modal");
//     // navigate('/admin/add-car') if you have a route
//   };

//   return (
//     <div className="bg-black text-white py-5 min-vh-100">
//       <Container>
//         <h3 className="text-danger text-center fw-bold mb-4">🛠️ Admin Dashboard</h3>
//         {error && <Alert variant="danger">{error}</Alert>}

//         <Tab.Container defaultActiveKey="users">
//           <Row>
//             <Col sm={3}>
//               <Nav variant="pills" className="flex-column bg-dark p-3 rounded shadow-sm">
//                 <Nav.Item><Nav.Link eventKey="users" className="text-white">Users</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="cars" className="text-white">Cars</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="bookings" className="text-white">Bookings</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="payments" className="text-white">Payments</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="reviews" className="text-white">Reviews</Nav.Link></Nav.Item>
//               </Nav>
//             </Col>

//             <Col sm={9}>
//               <Tab.Content>
//                 {/* Users */}
//                 <Tab.Pane eventKey="users">
//                   <h5 className="text-danger mb-3">👥 All Users</h5>
//                   <Table striped bordered hover variant="dark" className="rounded shadow-sm">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Name</th>
//                         <th>Email</th>
//                         <th>Phone</th>
//                         <th>Role</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {users.map(user => (
//                         <tr key={user.id}>
//                           <td>{user.id}</td>
//                           <td>{user.firstName} {user.lastName}</td>
//                           <td>{user.email}</td>
//                           <td>{user.phone}</td>
//                           <td>{user.role}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => deleteUser(user.id)}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* Cars */}
//                 <Tab.Pane eventKey="cars">
//                   <div className="d-flex justify-content-between align-items-center mb-3">
//                     <h5 className="text-danger">🚗 All Cars</h5>
//                     <Button variant="danger" size="sm" onClick={handleAddCar}>
//                       + Add Car
//                     </Button>
                    
//                   </div>
//                   <Table striped bordered hover variant="dark" className="rounded shadow-sm">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Make</th>
//                         <th>Model</th>
//                         <th>Year</th>
//                         <th>Price/Day</th>
//                         <th>Available</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {cars.map(car => (
//                         <tr key={car.id}>
//                           <td>{car.id}</td>
//                           <td>{car.make}</td>
//                           <td>{car.model}</td>
//                           <td>{car.year}</td>
//                           <td>₹{car.pricePerDay}</td>
//                           <td>{car.available ? "Yes" : "No"}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => deleteCar(car.id)}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* Bookings */}
//                 <Tab.Pane eventKey="bookings">
//                   <h5 className="text-danger mb-3">📅 All Bookings</h5>
//                   <Table striped bordered hover variant="dark" className="rounded shadow-sm">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>User</th>
//                         <th>Car</th>
//                         <th>Pickup</th>
//                         <th>Dropoff</th>
//                         <th>Cost</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {bookings.map(b => (
//                         <tr key={b.id}>
//                           <td>{b.id}</td>
//                           <td>{b.userId}</td>
//                           <td>{b.carId}</td>
//                           <td>{b.pickupDate}</td>
//                           <td>{b.dropoffDate}</td>
//                           <td>₹{b.totalCost}</td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* Payments */}
//                 <Tab.Pane eventKey="payments">
//                   <h5 className="text-danger mb-3">💳 All Payments</h5>
//                   <Table striped bordered hover variant="dark" className="rounded shadow-sm">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Booking ID</th>
//                         <th>Method</th>
//                         <th>Status</th>
//                         <th>Amount</th>
//                         <th>Date</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {payments.map(p => (
//                         <tr key={p.id}>
//                           <td>{p.id}</td>
//                           <td>{p.bookingId}</td>
//                           <td>{p.paymentMethod}</td>
//                           <td>{p.status}</td>
//                           <td>₹{p.amount}</td>
//                           <td>{new Date(p.paymentDate).toLocaleString()}</td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* Reviews */}
//                 <Tab.Pane eventKey="reviews">
//                   <h5 className="text-danger mb-3">📝 All Reviews</h5>
//                   <Table striped bordered hover variant="dark" className="rounded shadow-sm">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>User</th>
//                         <th>Car</th>
//                         <th>Rating</th>
//                         <th>Comment</th>
//                         <th>Date</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {reviews.map(r => (
//                         <tr key={r.id}>
//                           <td>{r.id}</td>
//                           <td>{r.userId}</td>
//                           <td>{r.carId}</td>
//                           <td>{r.rating}</td>
//                           <td>{r.comment}</td>
//                           <td>{new Date(r.postedAt).toLocaleString()}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => deleteReview(r.id)}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>
//               </Tab.Content>
//             </Col>
//           </Row>
//         </Tab.Container>
//       </Container>
//     </div>
//   );
// };

// export default DashboardAdmin;

 



// import React, { useEffect, useState } from 'react';
// import axios from '../services/Api';
// import { Container, Row, Col, Tab, Nav, Table, Button, Alert } from 'react-bootstrap';

// const DashboardAdmin = () => {
//   const [users, setUsers] = useState([]);
//   const [cars, setCars] = useState([]);
//   const [bookings, setBookings] = useState([]);
//   const [payments, setPayments] = useState([]);
//   const [reviews, setReviews] = useState([]);
//   const [error, setError] = useState('');

//   // Modal state
//   const [showDeleteModal, setShowDeleteModal] = useState(false);
//   const [carToDelete, setCarToDelete] = useState(null);

//   useEffect(() => {
//     fetchAllData();
//   }, []);

//   const fetchAllData = () => {
//     axios.get('/api/profile/admin/all')
//       .then(res => setUsers(res.data))
//       .catch(() => setError("Failed to load users"));

//     axios.get('/api/cars/admin')
//       .then(res => setCars(res.data))
//       .catch(() => setError("Failed to load cars"));

//     axios.get('/api/bookings/admin/all')
//       .then(res => setBookings(res.data))
//       .catch(() => setError("Failed to load bookings"));

//     axios.get('/api/payments/admin/all')
//       .then(res => setPayments(res.data))
//       .catch(() => setError("Failed to load payments"));

//     axios.get('/api/reviews/admin/all')
//       .then(res => setReviews(res.data))
//       .catch(() => setError("Failed to load reviews"));
//   };

//   const deleteUser = (id) => {
//     axios.delete(`/api/profile/admin/delete/${id}`)
//       .then(() => fetchAllData())
//       .catch(() => setError("Failed to delete user"));
//   };

//   const deleteReview = (id) => {
//     axios.delete(`/api/reviews/${id}`)
//       .then(() => fetchAllData())
//       .catch(() => setError("Failed to delete review"));
//   };

//   const handleAddCar = () => {
//     alert("Redirect to Add Car Page or open Add Modal");
//     // You can navigate to a car add form here
//   };

//     const handleAddUser = () => {
//     alert("Redirect to Add Car Page or open Add Modal");
//     // You can navigate to a car add form here
//   };


//   const handleConfirmDelete = () => {
//     axios.delete(`/api/cars/${carToDelete}`)
//       .then(() => {
//         setShowDeleteModal(false);
//         setCarToDelete(null);
//         fetchAllData();
//       })
//       .catch(() => {
//         setError("Failed to delete car");
//         setShowDeleteModal(false);
//       });
//   };

//   return (
//     <div className="bg-black text-white py-5 min-vh-100">
//       <Container>
//         <h3 className="text-danger text-center fw-bold mb-4">🛠️ Admin Dashboard</h3>
//         {error && <Alert variant="danger">{error}</Alert>}

//         <Tab.Container defaultActiveKey="users">
//           <Row>
//             <Col sm={3}>
//               <Nav variant="pills" className="flex-column bg-dark p-3 rounded shadow-sm">
//                 <Nav.Item><Nav.Link eventKey="users" className="text-white">Users</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="cars" className="text-white">Cars</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="bookings" className="text-white">Bookings</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="payments" className="text-white">Payments</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="reviews" className="text-white">Reviews</Nav.Link></Nav.Item>
//               </Nav>
//             </Col>

//             <Col sm={9}>
//               <Tab.Content>
//                 {/* USERS */}
//                 <Tab.Pane eventKey="users">
//                                   <div className="d-flex justify-content-between align-items-center mb-3">
//                     <h5 className="text-danger"> All Users</h5>
//                     <Button variant="danger" size="sm" onClick={handleAddUser}>+ Add User</Button>
//                   </div>
                  
//                   <Table striped bordered hover variant="dark">

//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Name</th>
//                         <th>Email</th>
//                         <th>Phone</th>
//                         <th>Role</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {users.map(user => (
//                         <tr key={user.id}>
//                           <td>{user.id}</td>
//                           <td>{user.firstName} {user.lastName}</td>
//                           <td>{user.email}</td>
//                           <td>{user.phone}</td>
//                           <td>{user.role}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => deleteUser(user.id)}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* CARS */}
//                 <Tab.Pane eventKey="cars">
//                   <div className="d-flex justify-content-between align-items-center mb-3">
//                     <h5 className="text-danger">🚗 All Cars</h5>
//                     <Button variant="danger" size="sm" onClick={handleAddCar}>+ Add Car</Button>
//                   </div>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Make</th>
//                         <th>Model</th>
//                         <th>Year</th>
//                         <th>Price/Day</th>
//                         <th>Available</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {cars.map(car => (
//                         <tr key={car.id}>
//                           <td>{car.id}</td>
//                           <td>{car.make}</td>
//                           <td>{car.model}</td>
//                           <td>{car.year}</td>
//                           <td>₹{car.pricePerDay}</td>
//                           <td>{car.available ? 'Yes' : 'No'}</td>
//                           <td>
//                             <Button
//                               variant="danger"
//                               size="sm"
//                               onClick={() => {
//                                 setCarToDelete(car.id);
//                                 setShowDeleteModal(true);
//                               }}
//                             >
//                               Delete
//                             </Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* BOOKINGS */}
//                 <Tab.Pane eventKey="bookings">
//                   <h5 className="text-danger mb-3">📅 All Bookings</h5>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>User</th>
//                         <th>Car</th>
//                         <th>Pickup</th>
//                         <th>Dropoff</th>
//                         <th>Cost</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {bookings.map(b => (
//                         <tr key={b.id}>
//                           <td>{b.id}</td>
//                           <td>{b.userId}</td>
//                           <td>{b.carId}</td>
//                           <td>{b.pickupDate}</td>
//                           <td>{b.dropoffDate}</td>
//                           <td>₹{b.totalCost}</td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* PAYMENTS */}
//                 <Tab.Pane eventKey="payments">
//                   <h5 className="text-danger mb-3">💳 All Payments</h5>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Booking ID</th>
//                         <th>Method</th>
//                         <th>Status</th>
//                         <th>Amount</th>
//                         <th>Date</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {payments.map(p => (
//                         <tr key={p.id}>
//                           <td>{p.id}</td>
//                           <td>{p.bookingId}</td>
//                           <td>{p.paymentMethod}</td>
//                           <td>{p.status}</td>
//                           <td>₹{p.amount}</td>
//                           <td>{new Date(p.paymentDate).toLocaleString()}</td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* REVIEWS */}
//                 <Tab.Pane eventKey="reviews">
//                   <h5 className="text-danger mb-3">📝 All Reviews</h5>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>User</th>
//                         <th>Car</th>
//                         <th>Rating</th>
//                         <th>Comment</th>
//                         <th>Date</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {reviews.map(r => (
//                         <tr key={r.id}>
//                           <td>{r.id}</td>
//                           <td>{r.userId}</td>
//                           <td>{r.carId}</td>
//                           <td>{r.rating}</td>
//                           <td>{r.comment}</td>
//                           <td>{new Date(r.postedAt).toLocaleString()}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => deleteReview(r.id)}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>
//               </Tab.Content>
//             </Col>
//           </Row>
//         </Tab.Container>
//       </Container>

//       {/* Delete Car Confirmation Modal */}
//       {showDeleteModal && (
//         <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
//           <div className="modal-dialog modal-dialog-centered">
//             <div className="modal-content bg-dark text-white">
//               <div className="modal-header border-0">
//                 <h5 className="modal-title text-danger">Confirm Deletion</h5>
//                 <button type="button" className="btn-close btn-close-white" onClick={() => setShowDeleteModal(false)}></button>
//               </div>
//               <div className="modal-body">
//                 <p>Are you sure you want to delete this car? This action cannot be undone.</p>
//               </div>
//               <div className="modal-footer border-0">
//                 <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
//                   Cancel
//                 </Button>
//                 <Button variant="danger" onClick={handleConfirmDelete}>
//                   Yes, Delete
//                 </Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default DashboardAdmin;


// DashboardAdmin.jsx
// import React, { useEffect, useState } from 'react';
// import axios from '../services/Api';
// import { Container, Row, Col, Tab, Nav, Table, Button, Alert } from 'react-bootstrap';

// const DashboardAdmin = () => {
//   const [users, setUsers] = useState([]);
//   const [cars, setCars] = useState([]);
//   const [bookings, setBookings] = useState([]);
//   const [payments, setPayments] = useState([]);
//   const [reviews, setReviews] = useState([]);
//   const [error, setError] = useState('');
//   const [showAddCarModal, setShowAddCarModal] = useState(false);
//   const [showAddUserModal, setShowAddUserModal] = useState(false);

//   const [carData, setCarData] = useState({
//     make: '', model: '', year: '', pricePerDay: '', available: true, location: '', imageUrl: ''
//   });

//   const [userData, setUserData] = useState({
//     firstName: '', lastName: '', email: '', password: '', phone: '', role: 'USER'
//   });

//   const [showDeleteModal, setShowDeleteModal] = useState(false);
//   const [deleteTarget, setDeleteTarget] = useState(null);

//   useEffect(() => {
//     fetchAllData();
//   }, []);

//   const fetchAllData = () => {
//     axios.get('/api/profile/admin/all').then(res => setUsers(res.data)).catch(() => setError("Failed to load users"));
//     axios.get('/api/cars/admin').then(res => setCars(res.data)).catch(() => setError("Failed to load cars"));
//    axios.get('/api/bookings/admin/all')
//   .then(res => setBookings(res.data))
//   .catch(err => {
//     console.error("Bookings API Error:", err.response?.status, err.response?.data);
//     setError("Failed to load bookings");
//   });

// axios.get('/api/payments/admin/all')
//   .then(res => setPayments(res.data))
//   .catch(err => {
//     console.error("Payments API Error:", err.response?.status, err.response?.data);
//     setError("Failed to load payments");
//   });

// axios.get('/api/reviews/admin/all')
//   .then(res => setReviews(res.data))
//   .catch(err => {
//     console.error("Reviews API Error:", err.response?.status, err.response?.data);
//     setError("Failed to load reviews");
//   });

//   };

//   const submitAddCar = () => {
//     axios.post('/api/cars/add', carData).then(() => {
//       fetchAllData();
//       setShowAddCarModal(false);
//       setCarData({ make: '', model: '', year: '', pricePerDay: '', available: true, location: '', imageUrl: '' });
//     }).catch(() => setError("Failed to add car"));
//   };

//   const submitAddUser = () => {
//     axios.post('/api/auth/register', userData).then(() => {
//       fetchAllData();
//       setShowAddUserModal(false);
//       setUserData({ firstName: '', lastName: '', email: '', password: '', phone: '', role: 'USER' });
//     }).catch(() => setError("Failed to add user"));
//   };

//   const deleteReview = (id) => {
//     axios.delete(`/api/reviews/${id}`).then(() => fetchAllData()).catch(() => setError("Failed to delete review"));
//   };

//   const handleAddCar = () => {
//     setShowAddCarModal(true);
//   };

//   const handleAddUser = () => {
//     setShowAddUserModal(true);
//   };

//   const handleConfirmDelete = () => {
//     if (!deleteTarget) return;
//     const { type, id } = deleteTarget;
//     const url = type === 'user' ? `/api/profile/admin/delete/${id}` : `/api/cars/delete/${id}`;
//     axios.delete(url).then(() => {
//       fetchAllData();
//       setShowDeleteModal(false);
//       setDeleteTarget(null);
//     }).catch((error) => {
//       setError(`Failed to delete ${type}: ${error?.response?.data || 'Unknown error'}`);
//       setShowDeleteModal(false);
//       setDeleteTarget(null);
//     });
//   };

//   useEffect(() => {
//   console.log("Token being sent:", localStorage.getItem('token'));
// });


//   return (
//     <div className="bg-black text-white py-5 min-vh-100">
//       <Container>
//         <h3 className="text-danger text-center fw-bold mb-4">🛠️ Admin Dashboard</h3>
//         {error && <Alert variant="danger">{error}</Alert>}

//         <Tab.Container defaultActiveKey="users">
//           <Row>
//             <Col sm={3}>
//               <Nav variant="pills" className="flex-column bg-dark p-3 rounded shadow-sm">
//                 <Nav.Item><Nav.Link eventKey="users" className="text-white">Users</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="cars" className="text-white">Cars</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="bookings" className="text-white">Bookings</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="payments" className="text-white">Payments</Nav.Link></Nav.Item>
//                 <Nav.Item><Nav.Link eventKey="reviews" className="text-white">Reviews</Nav.Link></Nav.Item>
//               </Nav>
//             </Col>

//             <Col sm={9}>
//               <Tab.Content>

//                 {/* USERS */}
//                 <Tab.Pane eventKey="users">
//                   <div className="d-flex justify-content-between align-items-center mb-3">
//                     <h5 className="text-danger">All Users</h5>
//                     <Button variant="danger" size="sm" onClick={handleAddUser}>+ Add User</Button>
//                   </div>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Name</th>
//                         <th>Email</th>
//                         <th>Phone</th>
//                         <th>Role</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {users.map(user => (
//                         <tr key={user.id}>
//                           <td>{user.id}</td>
//                           <td>{user.firstName} {user.lastName}</td>
//                           <td>{user.email}</td>
//                           <td>{user.phone}</td>
//                           <td>{user.role}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => {
//                               setDeleteTarget({ type: 'user', id: user.id });
//                               setShowDeleteModal(true);
//                             }}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* CARS */}
//                 <Tab.Pane eventKey="cars">
//                   <div className="d-flex justify-content-between align-items-center mb-3">
//                     <h5 className="text-danger">🚗 All Cars</h5>
//                     <Button variant="danger" size="sm" onClick={handleAddCar}>+ Add Car</Button>
//                   </div>
//                   <Table striped bordered hover variant="dark">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>Make</th>
//                         <th>Model</th>
//                         <th>Year</th>
//                         <th>Price/Day</th>
//                         <th>Available</th>
//                         <th>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {cars.map(car => (
//                         <tr key={car.id}>
//                           <td>{car.id}</td>
//                           <td>{car.make}</td>
//                           <td>{car.model}</td>
//                           <td>{car.year}</td>
//                           <td>₹{car.pricePerDay}</td>
//                           <td>{car.available ? 'Yes' : 'No'}</td>
//                           <td>
//                             <Button variant="danger" size="sm" onClick={() => {
//                               setDeleteTarget({ type: 'car', id: car.id });
//                               setShowDeleteModal(true);
//                             }}>Delete</Button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </Tab.Pane>

//                 {/* BOOKINGS, PAYMENTS, REVIEWS - (unchanged, omitted for brevity) */}

//               </Tab.Content>
//             </Col>
//           </Row>
//         </Tab.Container>
//       </Container>

//       {/* Delete Modal */}
//       {showDeleteModal && (
//         <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
//           <div className="modal-dialog modal-dialog-centered">
//             <div className="modal-content bg-dark text-white">
//               <div className="modal-header border-0">
//                 <h5 className="modal-title text-danger">Confirm Deletion</h5>
//                 <button type="button" className="btn-close btn-close-white" onClick={() => setShowDeleteModal(false)}></button>
//               </div>
//               <div className="modal-body">
//                 Are you sure you want to delete this {deleteTarget?.type}?
//               </div>
//               <div className="modal-footer border-0">
//                 <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
//                 <Button variant="danger" onClick={handleConfirmDelete}>Yes, Delete</Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* Add Car Modal */}
//       {showAddCarModal && (
//         <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
//           <div className="modal-dialog modal-dialog-centered">
//             <div className="modal-content bg-dark text-white">
//               <div className="modal-header border-0">
//                 <h5 className="modal-title text-danger">Add Car</h5>
//                 <button type="button" className="btn-close btn-close-white" onClick={() => setShowAddCarModal(false)}></button>
//               </div>
//               <div className="modal-body">
//                 <input type="text" placeholder="Make" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={carData.make} onChange={(e) => setCarData({ ...carData, make: e.target.value })} />
//                 <input type="text" placeholder="Model" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={carData.model} onChange={(e) => setCarData({ ...carData, model: e.target.value })} />
//                 <input type="number" placeholder="Year" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={carData.year} onChange={(e) => setCarData({ ...carData, year: e.target.value })} />
//                 <input type="number" placeholder="Price Per Day" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={carData.pricePerDay} onChange={(e) => setCarData({ ...carData, pricePerDay: e.target.value })} />
//                 <input type="text" placeholder="Location" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={carData.location} onChange={(e) => setCarData({ ...carData, location: e.target.value })} />
//                 <input type="text" placeholder="Image URL" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={carData.imageUrl} onChange={(e) => setCarData({ ...carData, imageUrl: e.target.value })} />
//               </div>
//               <div className="modal-footer border-0">
//                 <Button variant="secondary" onClick={() => setShowAddCarModal(false)}>Cancel</Button>
//                 <Button variant="danger" onClick={submitAddCar}>Add Car</Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* Add User Modal */}
//       {showAddUserModal && (
//         <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
//           <div className="modal-dialog modal-dialog-centered">
//             <div className="modal-content bg-dark text-white">
//               <div className="modal-header border-0">
//                 <h5 className="modal-title text-danger">Add User</h5>
//                 <button type="button" className="btn-close btn-close-white" onClick={() => setShowAddUserModal(false)}></button>
//               </div>
//               <div className="modal-body">
//                 <input type="text" placeholder="First Name" className="form-control mb-2 text-white bg-dark border-secondary italics"
//                   value={userData.firstName} onChange={(e) => setUserData({ ...userData, firstName: e.target.value })} />
//                 <input type="text" placeholder="Last Name" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={userData.lastName} onChange={(e) => setUserData({ ...userData, lastName: e.target.value })} />
//                 <input type="email" placeholder="Email" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={userData.email} onChange={(e) => setUserData({ ...userData, email: e.target.value })} />
//                 <input type="password" placeholder="Password" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={userData.password} onChange={(e) => setUserData({ ...userData, password: e.target.value })} />
//                 <input type="text" placeholder="Phone" className="form-control mb-2 text-white bg-dark border-secondary"
//                   value={userData.phone} onChange={(e) => setUserData({ ...userData, phone: e.target.value })} />
//               </div>
//               <div className="modal-footer border-0">
//                 <Button variant="secondary" onClick={() => setShowAddUserModal(false)}>Cancel</Button>
//                 <Button variant="danger" onClick={submitAddUser}>Add User</Button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default DashboardAdmin;


