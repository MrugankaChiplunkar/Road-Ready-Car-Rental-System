import React, { useEffect, useState } from 'react';
import axios from '../services/Api';
import { Container, Row, Col, Card, Button, Spinner } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import bgImage from '../assets/bg.png';

const CarList = () => {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('/api/cars')
      .then(res => setCars(res.data))
      .catch(err => console.error('Error fetching cars:', err))
      .finally(() => setLoading(false));
  }, []);

  const handleBook = (carId) => {
    navigate(`/book/${carId}`);
  };

  return (
    <div
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        minHeight: '100vh',
        paddingTop: '5rem',
        paddingBottom: '5rem',
        color: 'white'
      }}
    >
      <Container>
        <h2 className="text-center text-danger fw-bold mb-5">BROWSE AVAILABLE CARS</h2>

        {loading ? (
          <div className="text-center">
            <Spinner animation="border" variant="danger" />
          </div>
        ) : (
          <Row>
            {cars.map(car => (
              <Col key={car.id} md={4} sm={6} xs={12} className="mb-4">
                <Card className="h-100 shadow-lg border-0 bg-dark text-white">
                  <Card.Img
                    variant="top"
                    src={car.imageUrl || 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/2015_Toyota_Corolla_S.jpg/1200px-2015_Toyota_Corolla_S.jpg?20150330072821'}
                    alt={`${car.make} ${car.model}`}
                    style={{ height: '200px', objectFit: 'cover' }}
                  />
                  <Card.Body className="d-flex flex-column justify-content-between">
                    <Card.Title className="text-danger text-center">
                      {car.make} {car.model}
                    </Card.Title>
                    <Card.Text className="text-light text-center small">
                      Year: {car.year} <br />
                      Price/Day: ₹{car.pricePerDay} <br />
                      Location: {car.location}
                    </Card.Text>
                    <div className="text-center mt-3">
                      <Button variant="danger" onClick={() => handleBook(car.id)}>
                        Book
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        )}
      </Container>
    </div>
  );
};

export default CarList;

