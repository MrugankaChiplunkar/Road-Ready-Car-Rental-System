import React from 'react';
import '../App.css';

function Footer() {
  return (
    <footer className="bg-black text-white py-5">
      <div className="container text-center">
        <h4 className="fw-bold mb-4 p-5">GET IN TOUCH</h4>
        <div className="row">
          <div className="col-md-3 col-sm-6 mb-3">
            <h6 className="text-danger">Address</h6>
            <p>ABC XYZ, Pune, Maharashtra, India</p>
          </div>
          <div className="col-md-3 col-sm-6 mb-3">
            <h6 className="text-danger">Email Address</h6>
            <p>roadready@gmail.com</p>
          </div>
          <div className="col-md-3 col-sm-6 mb-3">
            <h6 className="text-danger">Phone Number</h6>
            <p>(123) 456 7890</p>
          </div>
          <div className="col-md-3 col-sm-6 mb-3">
            <h6 className="text-danger">Socials</h6>
            <p>@roadready</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;