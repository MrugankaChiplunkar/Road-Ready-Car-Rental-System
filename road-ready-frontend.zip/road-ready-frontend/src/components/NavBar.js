import React from 'react';
import { Navbar, Nav, Button, Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import {jwtDecode} from 'jwt-decode';

function NavBar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const isLoggedIn = !!token;
  let role = '';

  if (token) {
    try {
      const decoded = jwtDecode(token);
      role = decoded.roles?.[0];
    } catch (e) {
      role = '';
    }
  }

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const handleBrowseCars = () => {
    if (!isLoggedIn) {
      alert("Please login first");
    } else {
      navigate("/cars");
    }
  };

  return (
    <Navbar expand="lg" bg="black" variant="dark" className="shadow-sm">
      <Container>
        <Navbar.Brand as={Link} to="/" className="text-danger fw-bold fs-4">
          ROAD READY
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav" className="justify-content-between">
          <Nav className="mx-auto d-flex gap-4 align-items-center">
            <Nav.Link as={Link} to="/" className="text-white fw-bold">Home</Nav.Link>
            <Nav.Link onClick={handleBrowseCars} className="text-white fw-bold">Browse Cars</Nav.Link>
            {isLoggedIn && (
              <Nav.Link as={Link} to={role === 'ROLE_ADMIN' ? "/admin" : "/dashboard"} className="text-white fw-bold">
                Dashboard
              </Nav.Link>
            )}
          </Nav>
          <div className="d-flex align-items-center">
            {isLoggedIn ? (
              <Button variant="danger" onClick={handleLogout} className="px-3">Log Out</Button>
            ) : (
              <Button variant="danger" as={Link} to="/login" className="px-3">Login / Register</Button>
            )}
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavBar;
