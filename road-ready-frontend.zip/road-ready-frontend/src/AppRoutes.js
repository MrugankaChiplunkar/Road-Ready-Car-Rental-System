// src/AppRoutes.js
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import CarList from './pages/CarList';
import CarDetails from './pages/CarDetails';
import Booking from './pages/Booking';
import Payment from './pages/Payment';
import DashboardUser from './pages/DashboardUser';
import DashboardAdmin from './pages/DashboardAdmin';
import PaymentSuccess from './pages/PaymentSuccess';
import { isLoggedIn, getToken } from './utils/Auth';
import { jwtDecode } from 'jwt-decode';
import ProtectedRoute from './components/ProtectedRoute';


const isAdmin = () => {
  const token = getToken();
  if (!token) return false;
  const decoded = jwtDecode(token);
  return decoded.roles?.includes("ROLE_ADMIN");
};

const isUser = () => {
  const token = getToken();
  if (!token) return false;
  const decoded = jwtDecode(token);
  return decoded.roles?.includes("ROLE_USER");
};

const AppRoutes = () => {
  const isAdmin = () => {
  const token = getToken();
  if (!token) return false;
  const decoded = jwtDecode(token);
  console.log("Decoded Token:", decoded); // 👈 Add this line to inspect structure
  return decoded.roles?.includes("ROLE_ADMIN");
};

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
<Route path="/register" element={<Register />} />


{/* <Route path="/admin" element={isAdmin() ? <DashboardAdmin /> : <Navigate to="/login" />} />
<Route path="/dashboard" element={isUser() ? <DashboardUser /> : <Navigate to="/login" />} /> */}

<Route
  path="/admin"
  element={
    <ProtectedRoute role="ROLE_ADMIN">
      <DashboardAdmin />
    </ProtectedRoute>
  }
/>

<Route
  path="/dashboard"
  element={
    <ProtectedRoute role="ROLE_USER">
      <DashboardUser />
    </ProtectedRoute>
  }
/>


      <Route path="/cars" element={<CarList />} />
      <Route path="/car/:id" element={<CarDetails />} />
      <Route path="/book/:carId" element={<Booking />} />
      <Route path="/payment/:bookingId" element={<Payment />} />
      {/* <Route path="/dashboard" element={<DashboardUser />} />
      <Route path="/admin" element={<DashboardAdmin />} /> */}
      <Route path="/payment-success" element={<PaymentSuccess />} />
    </Routes>
    
  );

  
};

export default AppRoutes;
